//exam6-3.c
#include <time.h>
#include <lastlog.h>
#include <paths.h>  
#include <fcntl.h>
#include <stdio.h>  
#include <err.h>  
#include <stdlib.h> 
#include <unistd.h> 
#include <errno.h>  
#include <string.h>   
#include <pwd.h> 
int main(int argc, char *argv[])
{
	if (argc < 2){
		fprintf(stderr, "Usage: %s username [usename ...]  \n",argv[0]);
		exit(1);
	}
	int fd = open(_PATH_LASTLOG, O_RDONLY);
	if (fd == -1)
		err(1, "%s", _PATH_LASTLOG);
	for (int i = 1; i < argc; i++) {
		struct passwd *pwd;	
		pwd = getpwnam(argv[i]);
		if (pwd == NULL)
			exit(1);
		uid_t uid =pwd->pw_uid;
		if (uid == -1) {
			printf("No such user: %s\n", argv[i]);
			continue;
		}
	lseek(fd, uid * sizeof(struct lastlog), SEEK_SET);
	struct lastlog llog;
	if (read(fd, &llog, sizeof(struct lastlog)) <= 0) {
		printf("read failed for %s\n", argv[i]);
		continue;
	}
	printf("%-8.8s %-6.6s %-20.20s %s", argv[i], llog.ll_line,
	llog.ll_host, ctime((time_t *) &llog.ll_time));
	}
	close(fd);
	exit(0);
}
