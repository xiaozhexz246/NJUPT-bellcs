// exam6-9.c
#include <stdio.h>
#include <sys/stat.h>
#include <stdlib.h>
int main(int argc, char *argv[])
{
	if (argc != 3){
		fprintf(stderr, "Usage:%s dirname mode(octal)\n", argv[0]);
		exit(1);     
	}
	mode_t mode = strtol(argv[2], NULL, 8);
	mkdir(argv[1], mode); 
	exit(0);
}
