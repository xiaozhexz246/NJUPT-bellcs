//exam6-12.c
#include <sys/mount.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
 void Usage(const char *prgname)
{
	fprintf(stderr, "Usage: %s [options] source target\n", prgname);
	fprintf(stderr, "-t fstype   \n");
	fprintf(stderr, "-o data     \n");
	fprintf(stderr, "-f mountflags can include any of:\n");
	fprintf(stderr, "A - MS_NOATIME        \n");
	fprintf(stderr, "V - MS_NODEV          \n");
	fprintf(stderr, "E - MS_NOEXEC         \n");
	fprintf(stderr, "S - MS_NOSUID         \n");
	fprintf(stderr, "r - MS_RDONLY         \n");
	fprintf(stderr, "s - MS_SYNCHRONOUS     \n");
	exit(1);
}
int main(int argc, char *argv[])
{
    unsigned long flags = 9;
    char *data = NULL, *fstype = NULL;
    int opt;
	while ((opt = getopt(argc, argv, "o:t:f:")) != -1) {
		switch (opt) {
			case 'o':
				data = optarg;
				break;
			case 't':
				fstype = optarg;
				break;
			case 'f':
				for (int j = 0; j < strlen(optarg); j++) {
					switch (optarg[j]) {
						case 'A': flags |= MS_NOATIME;          break;
						case 'V': flags |= MS_NODEV;            break;
						case 'E': flags |= MS_NOEXEC;           break;
						case 'S': flags |= MS_NOSUID;           break;
						case 'r': flags |= MS_RDONLY;           break;
						case 's': flags |= MS_SYNCHRONOUS;      break;
						default:  Usage(argv[0]);
					}
			break;
			default:
				Usage(argv[0]);
			}
		}
	}
	if (argc != optind + 2)
		Usage(argv[0]);
	mount(argv[optind], argv[optind + 1], fstype, flags, data);
	exit(0);
}
