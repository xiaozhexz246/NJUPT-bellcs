//exam6-10.c
#include	<string.h>
#include	<unistd.h>
#include	<stdio.h>
#include	<sys/stat.h>
#include	<dirent.h>
ino_t getinode(char *fname)
{
	struct stat info;
	stat(fname, &info);
	return info.st_ino;
}
void inotoname(ino_t ino, char *buff, int buflen)
{
	DIR *pdir = opendir(".");
	struct dirent	*pdirent;		
	while ((pdirent = readdir(pdir)) != NULL)
		if (pdirent->d_ino == ino){
			strncpy(buff, pdirent->d_name, buflen);
			buff[buflen-1] = '\0';   
			closedir(pdir);
			return;
		}
}
void printpath(ino_t ino)
{
	if (getinode("..") != ino){
		chdir("..");
		char name[BUFSIZ];		
		inotoname(ino, name, BUFSIZ);
		ino_t ino = getinode(".");		
		printpath(ino);		
		printf("%s/", name);		
	}
	else
		printf("/");
}
int main()
{
	ino_t ino = getinode(".");
	printpath(ino);	
	putchar('\n');				
	return 0;
}
