//exam6-6.c
#include <sys/stat.h>
#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <err.h>
#include <sys/sysmacros.h>
int main(int argc, char *argv[])
{
	if (argc != 2) {
		fprintf(stderr, "Usage: %s <pathname>\n", argv[0]);
		exit(1);
	}
	struct stat sb;
	int ret = stat(argv[1], &sb);
	if (ret == -1)
	err(1, "%s", argv[1]);
	printf("File type:  ");
	switch (sb.st_mode & S_IFMT) {
		case S_IFBLK:  printf("block device\n");     break;
		case S_IFCHR:  printf("character device\n"); break;
		case S_IFDIR:  printf("directory\n"); break;
		case S_IFIFO:  printf("FIFO/pipe\n"); break;
		case S_IFLNK:  printf("symlink\n");   break;
		case S_IFREG:  printf("regular file\n");     break;
		case S_IFSOCK: printf("socket\n");    break;
		default:printf("unknown?\n");  break;
	}
	printf("I-node number:     %ld\n", (long) sb.st_ino);
	printf("mode:%o (octal)\n", sb.st_mode);
	printf("link count: %ld\n", (long) sb.st_nlink);
	printf("ownership:  UID = %ld   GID = %ld\n",
	(long) sb.st_uid, (long) sb.st_gid);
	printf("I/O block size: %ld bytes\n",
	(long) sb.st_blksize);
	printf("file size:  %lld bytes\n",
	(long long) sb.st_size);
	printf("blocks allocated:  %lld\n",
	(long long) sb.st_blocks);
	printf("last status change:%s", ctime(&sb.st_ctime));
	printf("last file access:  %s", ctime(&sb.st_atime));
	printf("last file modification:   %s", ctime(&sb.st_mtime));
	exit(0);
}
