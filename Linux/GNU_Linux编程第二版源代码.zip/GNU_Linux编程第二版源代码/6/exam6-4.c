//exam6-4.c
#define _GNU_SOURCE
#include <stdlib.h>
#include <stdio.h>
#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h>
#include <err.h>
void finddatablock(int fd, int start, int len)
{
	int locate = start;
	while(1){
		int offsetd = lseek(fd,locate,SEEK_DATA);
		if ( offsetd <0)
			break;
		int offseth = lseek(fd,offsetd,SEEK_HOLE);
		printf("datablock offset %d, size %d\n",offsetd,offseth- offsetd);
		if (offseth >= len)
			break;
		locate = offseth;	
	}
}
int main(int argc, char *argv[])
{
	if (argc != 7){
		fprintf(stderr, "Usage:%s filename  doffset1 len1 doffset2 len2 filelen\n", argv[0]);
		fprintf(stderr, "doffset1: first data block offset \n");
		fprintf(stderr, "len1: first data block length \n");
		fprintf(stderr, "doffset2: second data block offset \n");
		fprintf(stderr, "len2: second data block length \n");
		fprintf(stderr, "filelen: total file length \n");
		exit(1);     
	}
	int doffset1 = atol(argv[2]); 
	int len1 = atol(argv[3]);
	int doffset2 = atol(argv[4]); 
	int len2 = atol(argv[5]);
	int filelen = atol(argv[6]);
	int fd = open(argv[1], O_RDWR|O_CREAT, 0666);
	if (fd == -1)
		err(1, "%s", argv[1]);
	lseek(fd, doffset1, SEEK_SET);
	for (int i = 0; i < len1; i++)
		write(fd,"A", 1);	
	lseek(fd, doffset2, SEEK_SET);
	for (int i = 0; i < len2; i++)
		write(fd,"X", 1);	
	ftruncate(fd, filelen);
	struct stat stat;
	fstat(fd,&stat);
	printf("block size %ld number of blocks %lld file length %lld\n",
	(long)stat.st_blksize,(long long)stat.st_blocks,(long long)stat.st_size);
	finddatablock(fd, 0, stat.st_size);
	 close(fd);
	exit(0);
}
