//exam6-14.c
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
char buff[200];
int  main(int  argc, char *argv[])
{
	setvbuf(stdout, buff, _IONBF, 100);
	printf("h");
	sleep(2);
	printf("e");
	sleep(2);
	printf("l");
	printf("l");
	setvbuf(stdout, buff, _IOLBF, 100);
	printf("o");
	printf("\n");
	printf("bye");
	sleep(4);
	exit (0);
}
