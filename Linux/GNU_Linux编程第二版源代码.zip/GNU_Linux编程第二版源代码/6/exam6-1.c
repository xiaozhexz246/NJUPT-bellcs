// exam6-1.c
#include <stdio.h>
#include <fcntl.h>
#include <stdlib.h>
#include <unistd.h>
#include <err.h>
char buf[BUFSIZ];
int  main(int  argc, char *argv[])
{
	if (argc !=3) {
		fprintf(stderr, "Usage: %s filein fileout\n", argv[0]);
		exit(1);
	}
	int fds = open(argv[1], O_RDONLY);
	if (fds == -1)
		err(1, "%s", argv[1]);
	int fdt = open(argv[2], O_WRONLY|O_CREAT, 0666);
	ssize_t len;
	while ((len = read(fds, buf, BUFSIZ)) > 0)
		write(fdt, buf, len);
	close(fds);
	close(fdt);
}
