//exam6-2.c
#include <stdio.h>
#include <stdlib.h>
#include <sys/uio.h>
#include <fcntl.h>
#include <err.h>
#include <unistd.h>
int main(int argc, char *argv[])
{      
	if (argc != 2){
		fprintf(stderr, "Usage:%s file\n", argv[0]);
		exit(1);
	}
	int fd = open(argv[1], O_RDONLY);
	if (fd == -1)
		err(1, "%s", argv[1]);
	ssize_t totreq = 0;
	struct iovec iov[3];
	struct stat myStruct; 
	iov[0].iov_base = &myStruct;
	iov[0].iov_len = sizeof(struct stat);
	totreq += iov[0].iov_len;
	int x;
	iov[1].iov_base = &x;
	iov[1].iov_len = sizeof(x);
	totreq += iov[1].iov_len;
	char str[100];
	iov[2].iov_base = str;
	iov[2].iov_len = 100;
	totreq += iov[2].iov_len;
	ssize_t nread = readv(fd, iov, 3);
	if (nread < totreq)
		printf("read fewer bytes than requested\n");
	printf("total request %ld bytes\tread %ld bytes\n",
	(long) totreq, (long) nread);
	exit(0);
}
