//exam6-11.c
#define _XOPEN_SOURCE 500
#include <ftw.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
int display_info(const char *fpath, const struct stat *sb, int tflag, struct FTW *ftwbuf)
{
	printf("%-3s %2d ",
	(tflag == FTW_D) ?   "d"   : (tflag == FTW_DNR) ? "dnr" :
	(tflag == FTW_DP) ?  "dp"  : (tflag == FTW_F) ?   "f" :
	(tflag == FTW_NS) ?  "ns"  : (tflag == FTW_SL) ?  "sl" :
	(tflag == FTW_SLN) ? "sln" : "???",
	ftwbuf->level);
	if (tflag == FTW_NS)
		printf("-------");
	else
		printf("%-40s %7jd\n", fpath,(intmax_t) sb->st_size);
	return 0;    
}
int main(int argc, char *argv[])
{
	int opt, flags = 0;
	while ((opt = getopt(argc, argv, "dp")) != -1) {
		switch (opt) {
			case 'd':
				flags |= FTW_DEPTH;
				break;
			case 'p':
				flags |= FTW_PHYS;
				break;
			default:
				fprintf(stderr, "Usage:%s [-d] [-p[] path\n", argv[0]);
				exit(1);
		}
	}
	if (optind >= argc)
		printf("Usage:%s [-d] [-p[] path\n", argv[0]);
	nftw(argv[optind], display_info, 20, flags);
	exit(0);
}
