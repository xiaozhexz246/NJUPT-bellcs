//exam6-5.c
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
int main(int argc, char *argv[])
{
	if (argc !=2) {
		printf("Usage: %s filename\n",argv[0]);
		exit(1);
	}
	int fd = open(argv[1],O_WRONLY|O_CREAT,0644);
	int fd1 = dup2(fd,1); 
	printf("hello dup2:%d\n", fd1);
	write(fd, "end of program\n",15);
	return 0;
}
