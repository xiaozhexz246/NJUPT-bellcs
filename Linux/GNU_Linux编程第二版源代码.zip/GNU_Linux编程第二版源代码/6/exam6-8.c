//exam6-8.c          ////
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <err.h>
char buffer[BUFSIZ];
int main(int argc, char *argv[])
{
	ssize_t len = read(0, buffer, BUFSIZ);
	if (len <= 0)
		err(1, "read\n");
	printf("read %zd bytes\n", len);
	int flags = fcntl(1, F_GETFL, 0);
	flags |= O_NONBLOCK;
	fcntl(1, F_SETFL, flags);
	char * ptr = buffer;
	while (len > 0) 
	{
		int tmp = write(1, ptr, len);
		if (tmp > 0) {
			ptr += tmp;
			len -= tmp;
		}   
	}   
	flags &= ~O_NONBLOCK;
	fcntl(1, F_SETFL, flags);
	return 0;
}
