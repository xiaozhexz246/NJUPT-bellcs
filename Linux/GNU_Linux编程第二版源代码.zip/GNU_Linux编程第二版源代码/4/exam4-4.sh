#!/bin/bash
# exam4-4.sh
hour=$(date +%H)
case ${hour} in
(0[5-9]|1[01])  
	echo "Good morining" 
	;;
(1[2-7]) 
	echo "Good afternoon"
	;;
(*) 
	echo "Good evening "
	;;
esac