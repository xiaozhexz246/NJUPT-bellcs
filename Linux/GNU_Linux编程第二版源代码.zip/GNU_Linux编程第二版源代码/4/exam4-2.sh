#!/bin/bash
# exam4-2.sh
if (( ${#}!=2 ))
then
	echo "Usage: ${0} num1 num2"
	exit 1
fi	
if (( ${1}>${2} ))
then 
	echo "${1} is greater than ${2}"
	exit 0
fi
if (( ${1}<${2} ))
then
	echo "${1} is less than ${2}" 
	exit 0
fi
echo "${1} is equal to ${2}" 