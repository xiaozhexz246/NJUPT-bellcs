#!/bin/bash
# exam4-9.sh
prime()
{
	i=2
	while (( i<${1} ))
	do
		j=2
		flag=1    
		while  (( j<=i/2 ))
		do
			if   (( i%j==0 ))
			then flag=0;break
			fi
		(( j++ ))
		done
		if [ $flag -eq 1 ]
		then echo -n "${i} "
		fi
	(( i++ ))
	done
	echo
}
if  (( $#!=1)) || (($1<=2))
then
	echo "Usage:$0 num"
	exit 1
fi
prime ${1}