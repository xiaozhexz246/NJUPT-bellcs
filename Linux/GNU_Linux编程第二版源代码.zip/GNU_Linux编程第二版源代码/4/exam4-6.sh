#!/bin/bash
# exam4-6.sh
if (( ${#}<1))
then
	echo "Usage: $0 num1 num..."
	exit 1
fi	
smallest=${1}
for i in  ${*}
do
	if (( i<smallest ))
	then
		smallest=${i}
	fi
done
echo " the smallest number is: ${smallest}"