#!/bin/bash
# exam4-1.sh
var1="welcome to use Shell script"
echo ${var1}
cd /usr/lib
pwd