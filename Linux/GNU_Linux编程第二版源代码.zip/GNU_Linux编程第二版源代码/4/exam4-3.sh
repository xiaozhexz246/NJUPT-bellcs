#!/bin/bash 
# exam4-3.sh
echo -n "enter your login name:"
read name
if [ ${name} = ${USER} ]
then 
	echo  "nice to meet you"
else 
	echo "sorry ,try again"
fi