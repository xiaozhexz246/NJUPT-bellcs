#!/bin/bash
# exam4-5.sh
echo select
select sel in 'GNU/Linux' 'FreeBSD' 'Minix' 'quit'
do
	case ${sel} in
	('GNU/Linux')
		echo "www.gnu.org"
		;;
	('FreeBSD')
		echo "www.freebsd.org"
		;;
	('Minix')
		echo "www.minix3.org"
		;;
	('quit')
		echo "see you later"
		break
	esac
done