#!/bin/bash
# exam4-8.sh
if ((${#}!=1))
then
	echo "Usage: ${0} num"
	exit 1
fi	
i=1
sum=0
while (( i<=$1 ))
do
  (( sum+=i))
  ((i++))

done
echo the sum is ${sum}