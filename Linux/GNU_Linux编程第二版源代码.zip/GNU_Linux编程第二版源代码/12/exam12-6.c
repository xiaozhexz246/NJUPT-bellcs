//exam12-6.c
#include <sys/socket.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <stdlib.h>
#include <err.h>
#include <unistd.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/sendfile.h>
int main(int argc, char *argv[]) 
{ 
	if (argc != 3) {
		fprintf(stderr, "usage:%s <port> <filename>\n", argv[0]);
		exit(1);
	}
	int fd = open(argv[2], O_RDONLY);
	if (fd == -1)
		err(1, "%s", argv[2]);
	struct stat file_stat;
	fstat(fd,&file_stat);	
	int serv_sock = socket(PF_INET, SOCK_STREAM, 0);   
	struct sockaddr_in serv_addr;
	serv_addr.sin_family = AF_INET;
	serv_addr.sin_addr.s_addr = htonl(INADDR_ANY);
	serv_addr.sin_port = htons(atoi(argv[1]));
	bind(serv_sock, (struct sockaddr*) &serv_addr, sizeof(serv_addr));
	listen(serv_sock, 5);
	int fd_sock = accept(serv_sock, (struct sockaddr*)NULL, NULL);
	sendfile(fd_sock, fd, NULL, file_stat.st_size);
	close(fd_sock);
	close(serv_sock);
	close(fd);
    return 0;
}
