//exam12-9.c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/socket.h>
char buffer[BUFSIZ];
int main(int argc, char **argv)
{
	if (argc!=3){
		fprintf(stderr, "Usage:%s parentmsg childmsg\n", argv[0]);
		exit(1);
	}
	int sfd[2] = {0};
	socketpair(PF_UNIX, SOCK_STREAM, 0, sfd);
	pid_t pid = fork();
	if (pid == 0){
		close(sfd[1]);
		write(sfd[0], argv[2], strlen(argv[2]));
		read(sfd[0], buffer, BUFSIZ);
		printf("child process receive: %s\n", buffer);
		close(sfd[0]);
	}
    else{
		close(sfd[0]);
		read(sfd[1], buffer, BUFSIZ);
		printf("parent process, receive: %s\n", buffer);
		write(sfd[1], argv[1], strlen(argv[1]));
		close(sfd[1]);
		wait(NULL);
	}
	exit(0);
}
