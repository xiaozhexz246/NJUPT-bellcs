//exam12-5.c
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>
ssize_t readn(int fd, void *msg, size_t num)
{
	size_t nread;
	for (nread = 0; nread < num; ) {
		char *buffer = msg;
		ssize_t len = read(fd, buffer, num - nread);
		if (len == 0)               
			return nread;             
		if ((len == -1) && (errno == EINTR)) 
			continue;               
		if (len == -1)
			return nread;              
		nread += len;
		buffer += len;
	}
	return nread;                     
}
ssize_t writen(int fd, const void *msg, size_t num)
{
	size_t nwrite;
	for (nwrite = 0; nwrite < num; ) {
		const char *buffer = msg;
		ssize_t len = write(fd, buffer, num - nwrite);
		if ((len == -1) && (errno == EINTR))
				continue;            
		if (len == -1)
			return nwrite;
		nwrite += len;
		buffer += len;
	}
	return nwrite;                  
}
