//exam12-2.c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
char buffer[BUFSIZ];
int main(int argc, char **argv)
{
	if (argc!=3){
		fprintf(stderr, "Usage : %s <IP> <port>\n", argv[0]);
		exit(1);
	}
	int clnt_sock = socket(PF_INET, SOCK_STREAM, 0);   	
	struct sockaddr_in clnt_addr;
	clnt_addr.sin_family = AF_INET;
	clnt_addr.sin_addr.s_addr = inet_addr(argv[1]);
	clnt_addr.sin_port = htons(atoi(argv[2]));
	connect(clnt_sock, (struct sockaddr*)&clnt_addr, sizeof(clnt_addr));
	fputs("q to quit:\n", stdout);
	ssize_t num;
	for (;;) {
		fgets(buffer, BUFSIZ, stdin);
		if (!strcmp(buffer,"q\n")) 
			break;
		int len = send(clnt_sock, buffer, strlen(buffer), 0);
		for (int tmp_len = 0; tmp_len < len; )
		{  
			num = recv(clnt_sock, &buffer[tmp_len], len-tmp_len, 0);
			tmp_len += num;
		}		
		buffer[len] = 0;
		printf("%s\n", buffer);
	}
	shutdown(clnt_sock, SHUT_WR);
	num = recv(clnt_sock, buffer, BUFSIZ, 0);
	buffer[num] = 0;
	printf("%s\n", buffer);
	return 0;
}
