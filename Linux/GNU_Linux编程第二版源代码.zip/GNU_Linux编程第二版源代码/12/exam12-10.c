//exam12-10.c
#include <sys/socket.h>  
#include <stdio.h>  
#include <arpa/inet.h>  
#include <unistd.h>  
#include <string.h>  
#include <stdlib.h>  
#include <errno.h>
#include	<netinet/tcp.h>
char buffer[BUFSIZ];    
int main(int argc, char * argv[])  
{  
	if (argc!=2){
		fprintf(stderr, "Usage : %s <port>\n", argv[0]);
		exit(1);
	}
	int serv_sock = socket(AF_INET, SOCK_STREAM, 0);
	int flags =1;
    setsockopt(serv_sock, SOL_SOCKET, SO_REUSEADDR, &flags, sizeof(flags));
    setsockopt(serv_sock, SOL_SOCKET, SO_KEEPALIVE, &flags, sizeof(flags));
	struct linger ling = {1, 30};
    setsockopt(serv_sock, SOL_SOCKET, SO_LINGER, &ling, sizeof(ling));
    setsockopt(serv_sock, IPPROTO_TCP, TCP_NODELAY, &flags, sizeof(flags));
	struct timeval  tv; 
	tv.tv_sec = 5;
	tv.tv_usec = 0;
	struct sockaddr_in serv_addr;  
	serv_addr.sin_family = AF_INET;  
	serv_addr.sin_port = htons(atoi(argv[1]));
	serv_addr.sin_addr.s_addr = htonl(INADDR_ANY);  
	bind(serv_sock,(struct sockaddr *)&serv_addr, sizeof(serv_addr));
	listen(serv_sock, 5);
	struct sockaddr_in clt_addr;
	socklen_t length = sizeof(clt_addr);  
	int fd_sock = accept(serv_sock, (struct sockaddr*)&clt_addr, &length);  
	setsockopt(fd_sock, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
	for (;;) {
		ssize_t len = recv(fd_sock, buffer, BUFSIZ, 0);
		if ((len < 0) && ((errno == EAGAIN) || (errno == EINTR)))
			continue;
		if (strcmp(buffer,"q\n") == 0 || len <= 0)
			break;
        send(fd_sock, buffer, len, 0);
    }
    close(fd_sock);
    close(serv_sock);
    return 0;
}
