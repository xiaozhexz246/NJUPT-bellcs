//exam12-11.c
# include<pthread.h>
#include<sys/mman.h> 
#include<sys/socket.h>	
#include<errno.h>
#include<netdb.h> 
#include<signal.h>
#include<stdio.h>
#include<sys/wait.h>
#include<stdlib.h>
#include<unistd.h>
#include<fcntl.h>   
static pthread_mutex_t	*mptr;	
int	nchld;
pid_t *pids;
char buffer[BUFSIZ];	
void sighandler(int sig)
{
	for (int  i = 0; i < nchld; i++)
		kill(pids[i], SIGTERM);
	while (wait(NULL) > 0);
	if (errno != ECHILD)
		perror("wait error");
	exit(0);
}
void child_process(int listenfd)
{
	printf("child %d starting\n", getpid());
	for ( ; ; ) {
		pthread_mutex_lock(mptr);
		int fd_sock = accept(listenfd, NULL, NULL);
		pthread_mutex_unlock(mptr);
		ssize_t len;
		while ((len = read(fd_sock, buffer, BUFSIZ)) > 0)
			write(fd_sock, buffer, len);
		close(fd_sock);
		printf("child %d disconnected\n",getpid());
	}
}
int main(int argc, char **argv)
{
	if (argc != 3){
		fprintf(stderr, "Usage : %s <port> <nprocess>\n", argv[0]);
		exit(1);
	}
	int fd = open("/dev/zero", O_RDWR, 0);
	mptr = mmap(0, sizeof(pthread_mutex_t), PROT_READ|PROT_WRITE,
				MAP_SHARED, fd, 0);
	close(fd);
	pthread_mutexattr_t	mattr;
	pthread_mutexattr_init(&mattr);
	pthread_mutexattr_setpshared(&mattr, PTHREAD_PROCESS_SHARED);
	pthread_mutex_init(mptr, &mattr);
	int serv_sock = socket(PF_INET, SOCK_STREAM, 0);
	struct sockaddr_in serv_addr;
	serv_addr.sin_family = AF_INET;
	serv_addr.sin_addr.s_addr = htonl(INADDR_ANY);
	serv_addr.sin_port = htons(atoi(argv[1]));
	bind(serv_sock, (struct sockaddr*)&serv_addr, sizeof(serv_addr));
	listen(serv_sock, 3);
	nchld = atoi(argv[2]);
	pids = calloc(nchld, sizeof(pid_t));
	for (int i = 0; i < nchld; i++){
		int pid;
		if ((pid = fork()) == 0)
			child_process(serv_sock);	
		pids[i] = pid;
	}
	signal(SIGINT, sighandler);
	for ( ; ; )
		pause();	
	return 0;
}
