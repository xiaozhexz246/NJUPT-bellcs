//exam12-4.c
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <ctype.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
char buffer[BUFSIZ];
int main(int argc, char *argv[])
{
	if (argc < 4) {
		fprintf(stderr, "%s <ipaddr> <port> [msg]...\n", argv[0]);
		exit(1);
	}
	int clnt_sock = socket(AF_INET, SOCK_DGRAM, 0);      
	struct sockaddr_in serv_addr;
	serv_addr.sin_family = AF_INET;
	serv_addr.sin_port = htons(atoi(argv[2]));
	serv_addr.sin_addr.s_addr = inet_addr(argv[1]);
	for (int j = 0; j < argc; j++) {
		ssize_t len;
		sendto(clnt_sock, argv[j], strlen(argv[j]), 0, (struct sockaddr *)&serv_addr,sizeof(serv_addr));
		len = recvfrom(clnt_sock, buffer, BUFSIZ, 0, NULL, 0);
		printf("bufferonse %d: %.*s\n", j, (int) len, buffer);
	}
	exit(0);	
}
