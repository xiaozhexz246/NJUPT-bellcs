//exam12-7.c
#include <stdio.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <unistd.h>
#include <signal.h>
#define sockname  "/tmp/test_xy"
char buffer[BUFSIZ];		
int main(int argc, char *argv[])
{
	unlink(sockname);
    int sock = socket(AF_UNIX, SOCK_SEQPACKET, 0);
	struct sockaddr_un serv_addr;
	memset(&serv_addr, 0, sizeof(struct sockaddr_un));
	serv_addr.sun_family = AF_UNIX;
	strncpy(serv_addr.sun_path, sockname, sizeof(serv_addr.sun_path) - 1);
	bind(sock, (const struct sockaddr *) &serv_addr, sizeof(serv_addr));
	listen(sock, 20);
	for (;;) {
		int fd_sock = accept(sock, NULL, NULL);
		int result = 0, down_flag = 0;
		for (;;) {
			read(fd_sock, buffer, BUFSIZ);
			if (!strcmp(buffer, "quit")) {
				down_flag = 1;
				break;
			}			
			if (!strcmp(buffer, "end"))
				break;
			result += atoi(buffer);
			}
		sprintf(buffer, "%d", result);
		write(fd_sock, buffer, BUFSIZ);
		close(fd_sock);
		if (down_flag) 
			break;
	}
	close(sock);
	unlink(sockname);
	exit(0);
}
