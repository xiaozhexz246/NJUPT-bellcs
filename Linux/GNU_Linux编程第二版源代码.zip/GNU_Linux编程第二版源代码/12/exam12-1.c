//exam12-1.c
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
char buffer[BUFSIZ];
int main(int argc, char **argv)
{
	if (argc!=2){
	fprintf(stderr, "Usage : %s <port>\n", argv[0]);
		exit(1);
	}
	int serv_sock = socket(PF_INET, SOCK_STREAM, 0);   
		struct sockaddr_in serv_addr;
	serv_addr.sin_family = AF_INET;
	serv_addr.sin_addr.s_addr = htonl(INADDR_ANY);
	serv_addr.sin_port = htons(atoi(argv[1]));
	bind(serv_sock, (struct sockaddr*)&serv_addr, sizeof(serv_addr));
	listen(serv_sock, 5);
	int fd_sock = accept(serv_sock, (struct sockaddr*)NULL, NULL);
	ssize_t len;
	while ((len = recv(fd_sock, buffer, BUFSIZ, 0)) > 0){
		send(fd_sock, buffer, len, 0);
	}
	send(fd_sock, "Thank you\n", 10, 0);
	close(fd_sock);
	return 0;
}
