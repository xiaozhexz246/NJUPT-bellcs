//exam12-3.c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
char buffer[BUFSIZ];
int main(int argc, char **argv)
{
	if(argc != 2){
		fprintf(stderr, "Usage : %s <port>\n", argv[0]);
		exit(1);
	}
	int serv_sock = socket(PF_INET, SOCK_DGRAM, 0);
	struct sockaddr_in serv_addr;
	memset(&serv_addr, 0, sizeof(serv_addr));
	serv_addr.sin_family = AF_INET;
	serv_addr.sin_addr.s_addr = htonl(INADDR_ANY);
	serv_addr.sin_port = htons(atoi(argv[1]));
	bind(serv_sock, (struct sockaddr*) &serv_addr, sizeof(serv_addr));
	for (;;) {
		struct sockaddr_in clnt_addr;
		socklen_t addr_size = sizeof(clnt_addr);
		ssize_t len = recvfrom(serv_sock, buffer, BUFSIZ, 0, (struct sockaddr*)&clnt_addr, &addr_size);
		sendto(serv_sock, buffer, len, 0, (struct sockaddr*)&clnt_addr, addr_size);
	}
	close(serv_sock);
	return 0;
}
