//exam12-8.c
#include <stdio.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <unistd.h>
#define sockname "/tmp/test_xy"
char buffer[BUFSIZ];
int main(int argc, char *argv[])
{
	if (argc == 1){
		fprintf(stderr, "Usage : %s num1 num2...[DOWN]\n", argv[0]);
		fprintf(stderr, "DOWN: end service request\n");  
		exit(1);
	}
	int clnt_sock = socket(AF_UNIX, SOCK_SEQPACKET, 0);	
	struct sockaddr_un clnt_addr;
	clnt_addr.sun_family = AF_UNIX;
	strncpy(clnt_addr.sun_path, sockname, sizeof(clnt_addr.sun_path) - 1);
	connect (clnt_sock, (const struct sockaddr *) &clnt_addr, sizeof(clnt_addr));
	for (int i = 1; i < argc; ++i)
		write(clnt_sock, argv[i], strlen(argv[i]) + 1);
	ssize_t len = read(clnt_sock, buffer, BUFSIZ);
	buffer[len] = 0;
	printf("Result = %s\n", buffer);
	close(clnt_sock);
	exit(0);
}
