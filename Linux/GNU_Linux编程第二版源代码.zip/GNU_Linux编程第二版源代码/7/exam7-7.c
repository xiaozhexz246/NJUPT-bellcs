// exam7-7.c
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <signal.h>
#include <sys/wait.h>
void siginfohandler(int sig, siginfo_t *si, void *ucontext)
{
	int savedErrno = errno;
	printf("get signal %d\n", sig);
	printf("si_pid = %d\n", si->si_pid);
	while (wait(NULL) > 0)
		continue;
	errno = savedErrno;
}
int main(int argc, char *argv[])
{
	struct sigaction sa;
	sigemptyset(&sa.sa_mask);
	sa.sa_flags = SA_SIGINFO;
	sa.sa_sigaction = siginfohandler;
	sigaction(SIGCHLD, &sa, NULL);
	for (int i = 0; i < 5; i++) {
		switch (fork()) {
			case 0:
				printf("child pid = %d \n", getpid());
				sleep(i);
				exit(0);
			default:                        
				break;                      
		}
	}
	printf("parent pid = %d \n", getpid());
	sleep(100);
}
