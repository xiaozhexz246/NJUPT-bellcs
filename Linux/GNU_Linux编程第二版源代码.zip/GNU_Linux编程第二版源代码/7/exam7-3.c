// exam7-3.c
#include <signal.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
int main(int argc, char *argv[])
{
	if (argc != 2) {
		fprintf(stderr, "%s delay-secs]\n", argv[0]);
		exit(1);
	}
	printf("pid %ld\n",(long)getpid());
	sigset_t set;
	sigfillset(&set);
	sigprocmask(SIG_SETMASK, &set, NULL);
	sleep(atol(argv[1]));  
	for (;;) {
		siginfo_t si;
		int sig = sigwaitinfo(&set, &si);
		if ((sig == -1) || (sig == SIGINT || sig == SIGTERM)){
			printf("sigwaitinfo failed | SIGINT | SIGTERM\n");
			exit(0);
		}
		printf("get signal: %d\t%s\n", sig, strsignal(sig));
		printf("si_signo = %d, si_code = %d(%s), si_value = %d\n",
			si.si_signo, si.si_code,
			(si.si_code == SI_USER) ? "SI_USER":
			(si.si_code == SI_QUEUE) ? "SI_QUEUE":"other",
			si.si_value.sival_int);
		printf("si_pid = %ld\tsi_uid = %ld\n",(long) si.si_pid, (long) si.si_uid);
	}
}
