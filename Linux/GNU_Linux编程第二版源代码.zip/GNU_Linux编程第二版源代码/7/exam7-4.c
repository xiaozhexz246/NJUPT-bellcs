// exam7-4.c
#include <unistd.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
int main(void)
{
	sigset_t set;
	sigemptyset(&set);
	sigaddset(&set, SIGTERM); 
	sigprocmask(SIG_BLOCK, &set, NULL);
	kill(getpid(), SIGTERM);
	sigset_t pendset;
	sigpending(&pendset);
	if (sigismember(&pendset, SIGTERM)) 
		printf("SIGTERM had been blocked\n");
	sigprocmask(SIG_UNBLOCK, &set, NULL);
	printf("SIGTERM had been unblocked\n");
	pause();
}
