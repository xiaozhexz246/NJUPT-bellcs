// exam7-6.c
#include <sys/signalfd.h>
#include <signal.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
int main(int argc, char *argv[])
{
	sigset_t mask;
	sigemptyset(&mask);
	sigaddset(&mask, SIGQUIT);
	sigaddset(&mask, SIGUSR1);
	sigprocmask(SIG_BLOCK, &mask, NULL);
	int sfd = signalfd(-1, &mask, 0);
	for (;;) {
		struct signalfd_siginfo fdsi;
 		ssize_t s = read(sfd, &fdsi, sizeof(struct signalfd_siginfo));
		if (s != sizeof(struct signalfd_siginfo))
			exit(1);
		switch (fdsi.ssi_signo){
			case SIGUSR1:
				printf("get SIGUSR1\n");
				break;
			case SIGQUIT:
				printf("get SIGQUIT\n");
				break;
		}
	}
}
