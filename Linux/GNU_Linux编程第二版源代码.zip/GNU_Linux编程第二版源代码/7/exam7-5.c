// exam7-5.c
#define _POSIX_C_SOURCE 199309
#include <signal.h>
#include <stdio.h>
#include <unistd.h>
#include <time.h>
#include <stdlib.h>
void siginfohandler(int sig, siginfo_t *si, void *ucontext)
{
	printf("get signal %d\n", sig);
	printf("sival_int = %d\n", si->si_value.sival_int);
}
int main(int argc, char *argv[])
{
	if (argc != 3) {
		fprintf(stderr, "Usage: %s data num-sigs\n", argv[0]);
		exit(1);
	}
	struct sigaction sa;
	sa.sa_sigaction = siginfohandler;
	sigemptyset(&sa.sa_mask);
	sa.sa_flags = SA_SIGINFO;
	sigaction(SIGRTMIN, &sa, NULL);
	int sigData = atol(argv[1]);
	int numSigs = atol(argv[2]) ;
	for (int i = 0; i < numSigs; i++) {
		union sigval sv;
		sv.sival_int = sigData + i;
		sigqueue(getpid(), SIGRTMIN, sv);
	}
	sleep(10);
	exit(0);
}
