// exam7-2.c
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
void printSigset(sigset_t *sigset)
{
	int cnt = 0;
	for (int sig = 1; sig < NSIG; sig++) {
		if (sigismember(sigset, sig)) {
			cnt++;
		printf("pending signal:\t%d\t%s\n", sig, strsignal(sig));
		}
	}
	if (cnt == 0)
		printf("empty signal set\n");
}
int main(int argc, char *argv[])
{
	printf("blcok signals\n");
	sigset_t blocked;
	sigemptyset(&blocked);
	sigaddset(&blocked, SIGINT);
	sigaddset(&blocked, SIGQUIT);
	sigaddset(&blocked, SIGUSR1);
	sigprocmask(SIG_SETMASK, &blocked, NULL);
	sleep(100);
	sigset_t pending;
	sigpending(&pending);
	printSigset(&pending);
	printf("unblcok signals\n");
	sigemptyset(&blocked);
	sigprocmask(SIG_SETMASK, &blocked, NULL);
	pause();
    exit(0);
}
