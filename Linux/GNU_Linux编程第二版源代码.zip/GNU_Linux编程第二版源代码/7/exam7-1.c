// exam7-1.c
#include <unistd.h>
#include <signal.h>
#include <stdio.h>
#include <malloc.h>
#include <stdlib.h>
#include <sys/mman.h>
void siginfohandler(int sig, siginfo_t *si, void *ucontext)
{
	printf("Got SIGSEGV at address: %10p\n", si->si_addr);
    exit(1);
}
int main(int argc, char *argv[])
{
	struct sigaction sa;
	sa.sa_flags = SA_SIGINFO;
	sigemptyset(&sa.sa_mask);
	sa.sa_sigaction = siginfohandler;
	sigaction(SIGSEGV, &sa, NULL);
	int pagesize = sysconf(_SC_PAGE_SIZE);
	printf("pagesize: %d\n", pagesize);
	char *buffer = memalign(pagesize, 4 * pagesize);
	printf("Start of region: %10p\n", buffer);
	mprotect(buffer + pagesize * 2, pagesize, PROT_READ);
	for (char *p = buffer; ; )
		*(p ++) = 'a';
	printf("Loop completed\n");     
	exit(0);
}
