//exam11-3.c
#include <pthread.h>
#include <stdio.h>
#include <signal.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <err.h>
	pthread_t tid;
int nseconds, cnt = 0;
void sighandler(int sig)
{
	int s = pthread_cancel(tid);
	if (s != 0)
		err(1, "pthread_cancel");
}
void cleanup_handler(void *arg)
{
	printf("clean-up function called\n");
	cnt = 0;
}
void * thread_start(void *arg)
{
	printf("thread started\n");
	pthread_cleanup_push(cleanup_handler, NULL);
	time_t curr = time(NULL);
	time_t term = curr + nseconds;
	while (term >= time(NULL)) {
		pthread_testcancel();    
		if (curr < time(NULL)) {
			curr = time(NULL) ;
			printf("cnt = %d\n", cnt);  
			cnt ++;
		}
	}
	pthread_cleanup_pop(0);
	return NULL;
}
int main(int argc, char *argv[])
{
	if (argc != 2) {
		fprintf(stderr, "Usage: %s seconds\n", argv[0]);
		exit(1);
	}
	nseconds = atol(argv[1]);
	struct sigaction sa;
	sigemptyset(&sa.sa_mask);
	sa.sa_flags = 0;
	sa.sa_handler = sighandler;
	sigaction(SIGINT, &sa, NULL);
	int s = pthread_create(&tid, NULL, thread_start, NULL);
	if (s != 0)
		err(1, "pthread_create");
	void *res;
	s = pthread_join(tid, &res);
	if (s != 0)
		err(1, "pthread_join");
	if (res == PTHREAD_CANCELED)
		printf("Thread was canceled; cnt = %d\n", cnt);
	else
		printf("Thread terminated normally; cnt = %d\n", cnt);
	exit(0);
}
