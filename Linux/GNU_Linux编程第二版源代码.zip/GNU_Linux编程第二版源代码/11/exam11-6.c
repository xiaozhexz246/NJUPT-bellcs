//exam11-6.c
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
void * thread_start(void *arg)
{
	sigset_t *set = arg;
	int sig;
	for (;;) {
		sigwait(set, &sig);
		printf("thread got signal %d\n", sig);
	}
}
int main(int argc, char *argv[])
{
	sigset_t set;
	sigfillset(&set);
	pthread_sigmask(SIG_BLOCK, &set, NULL);
	pthread_t thread;
	pthread_create(&thread, NULL, &thread_start, (void *) &set);
	pause();     
}
