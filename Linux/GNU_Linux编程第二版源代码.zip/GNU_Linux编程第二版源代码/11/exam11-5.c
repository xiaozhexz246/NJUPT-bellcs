//exam11-5.c
#include <stdio.h>
#include <pthread.h>
#include <unistd.h> 
#include <stdlib.h>
pthread_mutex_t lock;
pthread_cond_t notempty, notfull;
int flag = 1, nprocd = 0, nmax;
void *producer(void* arg)
{
	while (flag) {
		pthread_mutex_lock(&lock);
		while (nprocd == nmax)
			pthread_cond_wait(&notfull, &lock);
		sleep(rand() % 5);
		nprocd ++;
		printf("producer nprocd:\t%d\n", nprocd);
		pthread_mutex_unlock(&lock);
		pthread_cond_signal(&notempty);
	}
	pthread_exit((void *)0);	
}
void *consumer(void * arg)
{
	while (flag) {
		pthread_mutex_lock(&lock);
		while (nprocd == 0)
			pthread_cond_wait(&notempty, &lock);
		sleep(rand() % 10);
		nprocd --;
		printf("consumer nprocd:\t%d\n", nprocd);
		pthread_mutex_unlock(&lock);	
		pthread_cond_signal(&notfull);
	}
	pthread_exit((void *)0);
}
int main(int argc, char *argv[])
{
	if (argc != 3) {
		fprintf(stderr, "Usage: %s max seconds\n", argv[0]);
		exit(1);
	}
	nmax = atol(argv[1]);
	int wtime = atol(argv[2]);
	pthread_mutex_init(&lock, NULL);
	pthread_cond_init(&notempty, NULL);
	pthread_cond_init(&notfull, NULL);
	pthread_attr_t attr;
	pthread_attr_init(&attr);
	pthread_t tp, tid;
	pthread_create(&tp, &attr, producer, NULL);  
	pthread_create(&tid, &attr, consumer, NULL); 
	sleep(wtime); 
	flag = 0;
	void *res;
	pthread_join(tp, &res);
	pthread_join(tid, &res);
   return 0;
}
