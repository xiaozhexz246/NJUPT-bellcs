//exam11-7.c
char buffer[32];
char *convert(int val){
	int q = val, p = 31;
	char flag = 0;
	buffer[p]= '\0';
	if ( val == 0){
		buffer[--p] = '0';
		return  &buffer[p];
	}
	if ( val < 0){
		flag = 1;
		q = - val;
	}
	while ( q != 0 ){
		buffer[--p] = '0' + q % 10;
		q = q /10;
	}
	if (flag ==1)
		buffer[--p] = '-';
	return  &buffer[p];
}
