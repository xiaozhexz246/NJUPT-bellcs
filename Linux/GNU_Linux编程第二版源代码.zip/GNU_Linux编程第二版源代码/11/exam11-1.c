//exam11-1.c
#define _GNU_SOURCE
#include <sys/wait.h>
#include <sys/utsname.h>
#include <sched.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#define STACK_SIZE (1024*1024)    
int childFunc(void *arg)
{
	struct utsname uts;
	sethostname(arg, strlen(arg));
	uname(&uts);
	printf("uts.nodename in child:%s\n", uts.nodename);
	return 0;    
}
int main(int argc, char *argv[])
{	
	if (argc < 2) {
		fprintf(stderr, "Usage: %s child-hostname\n", argv[0]);
		exit(1);
	}
	char *stack = malloc(STACK_SIZE);
	char *stackTop = stack + STACK_SIZE;  
	pid_t pid = clone(childFunc, stackTop, CLONE_NEWUTS | SIGCHLD, argv[1]);
	printf("clone() returned %ld\n", (long) pid);
	struct utsname uts;
	uname(&uts);
	printf("uts.nodename in parent: %s\n", uts.nodename);
	waitpid(pid, NULL, 0);
	printf("child has terminated\n");
	exit(0);
}
