//exam11-4.c
#include <stdio.h>
#include <pthread.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
pthread_mutex_t lock;
char buffer[BUFSIZ];
void * thread_start(void* arg) 
{
	char *ch = (char *)arg;
	pthread_mutex_lock(&lock);
	for (int j = 0 ; j < strlen(ch) ; j++)
		buffer[j] = ch[j];
	buffer[strlen(ch)] = 0;
	printf("%s\n", buffer);
	pthread_mutex_unlock(&lock);
	return NULL;
}
int main(int argc, char *argv[])
{
	pthread_attr_t attr;
	pthread_mutex_init(&lock, NULL);
	pthread_attr_init(&attr);
	pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);
	pthread_t tid1, tid2;
   pthread_create(&tid1, &attr, thread_start, "GNU/Linux");  
   pthread_create(&tid2, &attr, thread_start, "Debian");  
   sleep(10);
   return 0;
}
