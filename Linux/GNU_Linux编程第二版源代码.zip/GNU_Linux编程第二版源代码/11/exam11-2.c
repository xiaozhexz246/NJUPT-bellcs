//exam11-2.c
#include <pthread.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <ctype.h>
struct thread_info {    
    pthread_t thread_id; 
    int		thread_num;
};
void * thread_start(void *arg)
{
    struct thread_info *tinfo = arg;
    char *p;
    long ret = rand() % 1000;
    printf("Thread %d: top of stack near %p\n", tinfo->thread_num, &p);
	sleep(1111);
    pthread_exit((void *)ret);
}
int main(int argc, char *argv[])
{
    int opt;
	int stack_size = 2048*1024;
	int nthread = 2;
	while ((opt = getopt(argc, argv, "s:n:")) != -1) {
		switch (opt) {
			case 's':
				stack_size = atol(optarg)*1024;
				break;
			case 'n':
				nthread = atol(optarg);
				break;
			default:
				fprintf(stderr, "Usage:%s [-s stack-size(kb)] [-n num of threads] \n", argv[0]);
			exit(1);
 		}
	}
    pthread_attr_t attr;
	pthread_attr_init(&attr);
	pthread_attr_setstacksize(&attr, stack_size);
	pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_JOINABLE);
	pthread_attr_setschedpolicy(&attr, SCHED_FIFO);
    struct   sched_param  param;  
	param.sched_priority = 2;
	pthread_attr_setschedparam(&attr, &param);
	pthread_attr_setinheritsched(&attr, PTHREAD_EXPLICIT_SCHED);
	struct thread_info *tinfo;
	tinfo = calloc(nthread, sizeof(struct thread_info));
	for (int i = 0; i < nthread; i++) {
		tinfo[i].thread_num = i + 1;
		pthread_create(&tinfo[i].thread_id, &attr,&thread_start, &tinfo[i]);
	}
	pthread_attr_destroy(&attr);
	for (int i = 0; i < nthread; i++) {
	    long res;		
		pthread_join(tinfo[i].thread_id, (void *)&res);
		printf("Joined with thread %d; returned value was %ld\n",
		tinfo[i].thread_num, res);
	}
	free(tinfo);
	pthread_exit(NULL);
}
