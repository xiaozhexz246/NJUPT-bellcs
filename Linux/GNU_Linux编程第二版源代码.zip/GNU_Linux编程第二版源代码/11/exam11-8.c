//exam11-8.c
#include <stdlib.h>
#include <pthread.h>
static pthread_once_t once = PTHREAD_ONCE_INIT;
static pthread_key_t convert_key;
void buffer_destroy(void *buffer)
{
	free(buffer);
}
void buffer_key_alloc(void)
{
	pthread_key_create(&convert_key, buffer_destroy);
}
char *convert(int val){
	int q = val, p = 31;
	char flag = 0;
	pthread_once(&once, buffer_key_alloc);
	char *buffer = pthread_getspecific(convert_key);
	if (buffer == NULL) {
		buffer = malloc(256);
		pthread_setspecific(convert_key, buffer);
	}
	buffer[p]= '\0';
	if ( val == 0){
		buffer[--p] = '0';
		return  &buffer[p];
	}
	if ( val < 0){
		flag = 1;
		q = - val;
	}
	while ( q != 0 ){
		buffer[--p] = '0' + q % 10;
		q = q /10;
	}
	if (flag ==1)
		buffer[--p] = '-';
	return  &buffer[p];
}
