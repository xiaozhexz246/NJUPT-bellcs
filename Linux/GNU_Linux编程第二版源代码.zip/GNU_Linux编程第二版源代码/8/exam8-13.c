//exam8-13.c
#include <sys/stat.h>
#include <sys/file.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <stdlib.h>
#include <unistd.h>
#include <err.h>
#include <signal.h>
#include <time.h>
#define TS_BUF_SIZE sizeof("YYYY-MM-DD HH:MM:SS")       
const char *CONFIG = "/test/test.conf";
const char *LOGFILE = "/test/test.log";
const char *MUTEXFIKE = "/test/test.pid";
#define BD_MAX_CLOSE  8192
void writelog(char *msg)
{
	FILE *fp = fopen(LOGFILE, "a");
	if (fp == NULL)
		err(1, "%s", LOGFILE);
	time_t t = time(NULL);
	struct tm *loc = localtime(&t);
	char timestamp[100];
	strftime(timestamp, TS_BUF_SIZE, "%F %X", loc);
	fprintf(fp, "%s: ", timestamp);
	fprintf(fp, "%s: ", msg);
	fprintf(fp, "\n");
	fclose(fp);
}
void bootmutex(const char *fname)
{
	int fd = open(fname, O_RDWR);
	if (flock(fd, LOCK_EX|LOCK_NB) == -1){
		writelog("can not run twice");
		_exit(0);
	}
}
void sighandler(int sig)
{
	int errsave;
	errsave = errno;
	switch (sig){
		FILE *fp;
		case SIGHUP:
			fp = fopen(CONFIG, "r");
			if (fp == NULL)
				err(1, "%s", CONFIG);
			fclose(fp);
			writelog("reconfig");
			break;
		case SIGTERM:
			writelog("shutdown");
			break;
	}
	errno = errsave;
}
int becomedaemon()
{
	switch (fork()) {
	case 0:  
		break;                     
	default: 
		_exit(0);       
    }
	if (setsid() < 0)                 
		return -1;
	umask(0);                       
	chdir("/");                     
	int maxfd = sysconf(_SC_OPEN_MAX);
	if (maxfd == -1)                
		maxfd = BD_MAX_CLOSE;       
	for (int fd = 0; fd < maxfd; fd++)
		close(fd);
	int fd = open("/dev/null", O_RDWR);
	if (fd != 0)         
		return -1;
	if (dup2(0, 1) != 1)
		return -1;
	if (dup2(0, 2) != 2)
		return -1;
	return 0;
}
int main(int argc, char *argv[])
{
	struct sigaction sa;
	sigemptyset(&sa.sa_mask);
	sa.sa_flags = SA_RESTART;
	sa.sa_handler = sighandler;
	sigaction(SIGHUP, &sa, NULL);
	sa.sa_handler = sighandler;
	sigaction(SIGTERM, &sa, NULL);
	if (becomedaemon() == -1)
		_exit(1);
	bootmutex(MUTEXFIKE);
	for (;;) {
		sleep(5);
	}
	_exit(0);
}
