//exam8-11.c
#include <sys/time.h>
#include <sys/resource.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
void usage(const char *prgname)
{
	fprintf(stderr, "Usage: %s [-p|g|u priority] [who]\n", prgname);
	fprintf(stderr, "-p a process \n");
	fprintf(stderr, "-g  process group\n");
	fprintf(stderr, "-u processes for user\n");
	exit(1);
}
int main(int argc, char *argv[])
{
	int opt;
	int which, prio;
	which = PRIO_PROCESS;
	while ((opt = getopt(argc, argv, "p:g:u:")) != -1) {
		switch (opt) {
			case 'p':
				which = PRIO_PROCESS;
				prio = atol(optarg);				
				break;
			case 'g':
				which = PRIO_PGRP;
				prio = atol(optarg);
				break;
			case 'u':
				which = PRIO_USER;
				prio = atol(optarg);
				break;
			default:
				usage(argv[0]);
		}
	}
	id_t who = (optind  < argc) ? atol(argv[optind]):0;
	setpriority(which, who, prio);
    prio = getpriority(which, who);
	printf("Nice value = %d\n", prio);
	return 0;
}
