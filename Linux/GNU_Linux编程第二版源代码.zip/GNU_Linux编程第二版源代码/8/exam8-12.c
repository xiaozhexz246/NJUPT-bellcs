//exam8-12.c
#define _GNU_SOURCE
#include <sched.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
int main(int argc, char *argv[])
{
	if (argc != 4) {
		fprintf(stderr, "Usage:%s parent-cpu child-cpu num-loops\n", argv[0]);
		exit(1);
	}
	int parentCPU = atoi(argv[1]);
	int childCPU = atoi(argv[2]);
	int nloops = atoi(argv[3]);
	cpu_set_t set;
	CPU_ZERO(&set);
	switch (fork()) {
		int j;
		case -1:     
			exit(1);
		case 0:      
			printf("child process start runing\n");
			CPU_SET(childCPU, &set);
			sched_setaffinity(getpid(), sizeof(set), &set);
			for (j = 0; j < nloops; j++)
				getppid();
			exit(0);
		default:
			printf("parent process start runing\n");     
			CPU_SET(parentCPU, &set);
			sched_setaffinity(getpid(), sizeof(set), &set);
			for (j = 0; j < nloops; j++)
			getppid();
			wait(NULL);     
			printf("both finished\n");
			exit(0);
	}
}
