// exam8-1.c
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/mman.h>
extern char etext, edata, end; 
extern char **environ;
int glob1;
int glob2 = 8;
int  func() {
    int flocal;
	printf("flocal at             %10p\n", &flocal);
	return 1;
}
int main(int argc, char *argv[]){
	char  *bv;
	int local,*pint;
	printf("environ[0] at         %10p\n", &environ[0]);
	printf("argv[1] at            %10p\n", &argv[1]);
	printf("argv[0] at            %10p\n", &argv[0]);
	printf("argc at               %10p\n", &argc);
	printf("local at              %10p\n", &local);
	local = func();
	void *map_addr11, *map_addr12;
	map_addr11 = mmap(NULL, 4096, PROT_READ | PROT_WRITE,
		MAP_SHARED | MAP_ANONYMOUS, -1, 0);
  	printf("map_addr11 at         %10p\n", map_addr11);
	map_addr12 = mmap(NULL, 4096, PROT_READ | PROT_WRITE,
		MAP_SHARED | MAP_ANONYMOUS, -1, 0);
  	printf("map_addr12 at         %10p\n", map_addr12);
	munmap(map_addr11, 4096 );
	munmap(map_addr12, 4096 );
	bv = sbrk(0);
	printf("Current brk         %10p\n", bv);
	brk(bv+512); 
	bv = sbrk(0);
	printf("Current brk:        %10p\n", bv);
	pint = malloc(sizeof(int));
	printf("pin at              %10p\n", pint);
	printf("end at              %10p\n", &end);
	printf("glob1 at            %10p\n", &glob1);
	printf("edata at            %10p\n", &edata);	
	printf("glob2 at            %10p\n",&glob2);
	printf("etext at            %10p\n", &etext);
	printf("func at             %10p\n", func);
	return 0;
}
