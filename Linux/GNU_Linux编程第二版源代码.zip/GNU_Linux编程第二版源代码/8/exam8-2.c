// exam8-2.c
#include <stdio.h>
#include <stdlib.h>
extern char **environ;
int main(int argc, char *argv[])
{
	for (int j = 0; j < argc; j++)
		printf("argv[%d]: %s \n", j, argv[j]);
	for (int j = 0; environ[j]; j++)
		printf("environ[%d]:%s\n", j, environ[j]);
    exit(0);
}
