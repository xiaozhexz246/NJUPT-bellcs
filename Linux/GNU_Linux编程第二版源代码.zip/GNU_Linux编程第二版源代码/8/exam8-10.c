//exam8-10.c
#include <sched.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/resource.h>
void usage(const char *prgname)
{
	fprintf(stderr, "Usage: %s [-r] [-f] [-o] priority \n", prgname);
	fprintf(stderr, "-r  round-robin policy.\n");
	fprintf(stderr, "-f first-in, first-out policy\n");
	fprintf(stderr, "-o standard round-robin time-sharing policy\n");
	exit(1);
}
void process_info(pid_t pid, int pol, struct sched_param sp) 
{
	char *name = "normal";
	int prio = sp.sched_priority;
	switch (pol) {
		case SCHED_OTHER:
			name = "OTHER";
			break;
		case SCHED_FIFO:
			name = "FIFO";
			break;
		case SCHED_RR:
			name = "RR";
			break;
	}
	printf("pid = %d \n", pid);
	printf("policy = %s\n", name);
	printf("priority = %2d\n", prio);
}
int main(int argc, char *argv[])
{
	int opt;
	int policy = SCHED_OTHER;
	while ((opt = getopt(argc, argv, "ofr")) != -1) {
		switch (opt) {
		case 'o':
			policy = SCHED_OTHER;
			break;
		case 'f':
			policy = SCHED_FIFO;
			break;
		case 'r':
			policy = SCHED_RR;
			break;
		default:
			usage(argv[0]);
		}
	}
	if (optind >argc -1)
		usage(argv[0]);
	int prio = atol(argv[optind]);
	pid_t pid = getpid();
	int pol = sched_getscheduler(pid);
    struct sched_param sp;
	sched_getparam(pid, &sp);
	process_info(pid, pol, sp);
	sp.sched_priority = prio;
	sched_setscheduler(pid, policy,&sp);
	pol = sched_getscheduler(pid);
	sched_getparam(pid, &sp);
	process_info(pid, pol, sp);
	sleep(2);
	return 0;
}
