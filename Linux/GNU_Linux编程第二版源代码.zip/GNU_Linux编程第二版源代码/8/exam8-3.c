// exam8-3.c
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
int	glob = 10;
int main(int argc, char *argv[])
{
 	int  local;
	local = 8;
	pid_t pid;
	if ((pid = fork()) == 0) { 
		sleep(2222);
	} else {
		glob ++;
		local --;
		sleep(1111);
	}
	printf("pid = %d, glob = %d, localar = %d\n", getpid(), glob, local);
	exit (0);
}
