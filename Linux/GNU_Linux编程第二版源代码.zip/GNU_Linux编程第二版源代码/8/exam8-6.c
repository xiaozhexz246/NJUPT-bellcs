//exam8-6.c
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <elf.h>
#include <err.h>
#include <fcntl.h>
#include <sys/mman.h>
#ifdef __x86_64__			
typedef  Elf64_Ehdr    Elf_Ehdr_t;
typedef  Elf64_Phdr    Elf_Phdr_t;
typedef  Elf64_auxv_t  Elf_auxv_t;
#elif  __i386__
typedef  Elf32_Ehdr    Elf_Ehdr_t ;
typedef  Elf32_Phdr    Elf_Phdr_t;
typedef  Elf32_auxv_t  Elf_auxv_t;
#endif
#define ROUND(x, align)   (void *)(((uintptr_t)x) & ~(align - 1))
#define MOD(x, align)     (((uintptr_t)x) & (align - 1))
#define PUSH(sp, T, ...) ( { *((T*)sp) = (T)__VA_ARGS__; sp = (void *)((uintptr_t)(sp) + sizeof(T)); })
#define STKSIZE            (1 << 20)
int main(int argc, char *argv[], char *envp[])
{
	if (argc < 2) {
		fprintf(stderr, "Usage: %s filename\n", argv[0]);
        exit(1);
	}
	int fd = open(argv[1], O_RDONLY);
	if (fd == -1)
		err(1, "%s", argv[1]);
	Elf_Ehdr_t *ehdr = mmap(NULL, 4096, PROT_READ, MAP_PRIVATE, fd, 0);
	if  (ehdr->e_type != ET_EXEC)
		err(1,"%s is mot exec\n",argv[1]);
	Elf_Phdr_t *phtbl = (Elf_Phdr_t *)((char *)ehdr + ehdr->e_phoff);
	for (int i = 0; i < ehdr->e_phnum; i++) {
	Elf_Phdr_t *phdr = &phtbl[i];
	if (phdr->p_type == PT_LOAD) {
		int prot = 0;
		if (phdr->p_flags & PF_R) prot |= PROT_READ;
		if (phdr->p_flags & PF_W) prot |= PROT_WRITE;
		if (phdr->p_flags & PF_X) prot |= PROT_EXEC;
		void *ret = mmap(
        ROUND(phdr->p_vaddr, phdr->p_align),              
		phdr->p_memsz + MOD(phdr->p_vaddr, phdr->p_align),   
		prot,                                       
		MAP_PRIVATE | MAP_FIXED,                    
		fd,                                         
		(uintptr_t)ROUND(phdr->p_offset, phdr->p_align)); 
		if (ret == (void *)-1)
		err(1,"mmap\n");
			memset((void *)(phdr->p_vaddr + phdr->p_filesz), 0, phdr->p_memsz - phdr->p_filesz);
		}
	}
   close(fd);
	static char stack[STKSIZE], rnd[16];
 	void *sp = ROUND(  &stack[STKSIZE]  - 4096, 16);
	void *bp = sp;
	PUSH(sp, intptr_t, argc-1); 
	for (int i = 1; i <= argc; i++)
		PUSH(sp, intptr_t, argv[i]);
	while (*envp)
		PUSH(sp, intptr_t, *envp++);
  	PUSH(sp, intptr_t, 0);
	PUSH(sp, Elf_auxv_t, { .a_type = AT_RANDOM, .a_un.a_val = (uintptr_t)rnd } );
	PUSH(sp, Elf_auxv_t, { .a_type = AT_NULL } );
	asm volatile(
#ifdef  __x86_64__		
		"mov $0, %%rdx;" 
		"mov %0, %%rsp;"
#elif  __i386__
		"mov $0, %%edx;" 
		"mov %0, %%esp;"
#endif
		"jmp *%1" :: "a"(bp), "b"(ehdr->e_entry)
	);
}
