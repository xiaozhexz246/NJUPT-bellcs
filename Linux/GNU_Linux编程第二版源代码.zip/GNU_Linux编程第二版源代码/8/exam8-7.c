//exam8-7.c
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#define MAX_CMD_LEN 200
int main(int argc, char *argv[])
{
	int ret;
	do {
		printf("command:");
		fflush(stdout);
		char str[MAX_CMD_LEN];	
		if (fgets(str, MAX_CMD_LEN, stdin) == NULL)
			break;              
		ret = system(str);
	}while (!WIFSIGNALED(ret) && !(WTERMSIG(ret) == SIGINT || WTERMSIG(ret) == SIGQUIT));
	printf("see you later\n:");
	exit(0);
}
