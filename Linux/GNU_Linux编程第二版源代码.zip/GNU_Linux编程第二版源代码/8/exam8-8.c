//exam8-8.c
#include <sys/wait.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <err.h>
void do_parent(int pid){
	int wstatus;
	do {
		int w = waitpid(pid, &wstatus, WUNTRACED | WCONTINUED);
		if (w == -1)
			err(1, "waitpid\n");
		if (WIFEXITED(wstatus)) 
			printf("exited, status = %d\n", WEXITSTATUS(wstatus));
		if (WIFSIGNALED(wstatus))
			printf("killed by signal %d\n", WTERMSIG(wstatus));
		if (WIFSTOPPED(wstatus)) 
			printf("stopped by signal %d\n", WSTOPSIG(wstatus));
		if (WIFCONTINUED(wstatus)) 
			printf("continued\n");
	} while (!WIFEXITED(wstatus) && !WIFSIGNALED(wstatus));
}
int main(int argc, char *argv[])
{
    if (argc !=1) {
    	fprintf(stderr, "Usage: %s \n", argv[0]);
        exit(1);
	}
	pid_t pid = fork();
	switch (pid) {
		case 0:
			printf("child pid = %d\n", getpid());
	 		pause();
			_exit(0);
		default:
			do_parent(pid);
	}
	exit(0);
}
