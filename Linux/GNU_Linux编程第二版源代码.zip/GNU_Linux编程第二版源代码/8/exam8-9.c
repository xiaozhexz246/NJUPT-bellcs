//exam8-9.c
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <sys/wait.h>
int nchld = 0;
void sighandler(int sig)
{    
	int savedErrno = errno;
	pid_t pid;
	int status;
	while ((pid = waitpid(-1, &status, WNOHANG)) > 0) {
		printf("receive SIGCHLD %ld  \n", (long) pid);
		nchld --;
	}
	if (pid == -1 && errno != ECHILD)
		printf("waitpid failed\n");
	errno = savedErrno;
}
int main(int argc, char *argv[])
{	
	if (argc < 2) {
		fprintf(stderr, "%s child-sleep-time ...\n", argv[0]);
		exit(1);
	}
	int sigCnt = 0;
	nchld = argc - 1;
	struct sigaction sa;
	sigemptyset(&sa.sa_mask);
	sa.sa_flags = 0;
	sa.sa_handler = sighandler;
	if (sigaction(SIGCHLD, &sa, NULL) == -1)
		exit(1);
	for (int j = 1; j < argc ; j++) {
		switch (fork()) {
			case 0:         
				sleep(atol(argv[j]));
				_exit(0);
			default:        
				break;
		}
	}
	sigset_t  emptyMask;
	sigemptyset(&emptyMask);
	while (nchld > 0) {
		if (sigsuspend(&emptyMask) == -1 && errno != EINTR)
			exit(1);
		sigCnt ++;
	}
	printf(" All %d children have terminated; SIGCHLD was caught "
		"%d times\n", argc - 1, sigCnt);
	exit(0);
}
