//exam8-4.c
#include <stdlib.h>
#include <stdio.h>
void my_exit1(void)
{
	printf("first exit handler\n");
}
void my_exit2(void)
{
	printf("second exit handler\n");
}
int main(int argc, char *argv[])
{
	if (atexit(my_exit1) != 0)
		printf("can't register my_exit1");
	if (atexit(my_exit2) != 0)
		printf("can't register my_exit2");
	printf("main is done\n");
	return 0;
}
