//exam9-5.c
#include <stdio.h>
#include <sys/msg.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <err.h>
#define MAX_LINE	80
struct mymsg{
     long  type;           	     
     float fval;            	 
     unsigned int uival;      	 
     char strval[MAX_LINE];    
} msg;
void usage(char *prgname)
{
	fprintf(stderr, "Usage:%s   -<c|s message|r|d> msgid\n", prgname);
	fprintf(stderr, "-c: create Message Queue\n");
	fprintf(stderr, "-s: send Message Queue\n");
	fprintf(stderr, "-r: receive Message Queue\n");
	fprintf(stderr, "-d: delete Message Queue\n");
	exit(1);
}
void sysv_msg(char cmd, key_t id, int msgflg)
{
	int msgid = msgget(id, msgflg);
	if (msgid == -1)
			err(1,"msgget\n");
	switch (cmd) {
		case 'c':
			printf("Created a Message Queue %d\n", msgid);
			break;
		case 's':
			msg.type = 1L;
		    msg.fval = 128.256;
		    msg.uival = 512;
			msgsnd(msgid,(struct msgbuf *)&msg, sizeof(msg), 0);
			printf("msg send success \n");
			break;
		case 'r':
			msgrcv(msgid,(struct msgbuf *)&msg, sizeof(msg), 1, 0);
			printf("type:         %ld\n", msg.type);
			printf("float Value:  %f\n", msg.fval);
			printf("uint Value:   %d\n", msg.uival);
			printf("string Value: %s\n", msg.strval);
			break;
		case 'd':
			msgctl(msgid, IPC_RMID, NULL);
			printf("delete success \n");
			break;
	}
}
int main(int argc, char *argv[])
{
	int opt, msgflg = 0;
	char flag = 'c';
	while ((opt = getopt(argc, argv,"cs:rd")) != -1) {
		switch (opt) {
		case 'c':
			flag = 'c';
			msgflg = IPC_CREAT | 0666;
			break;
		case 's':
			flag = 's';
			strncpy(msg.strval, optarg, strlen(optarg));
			break;
		case 'r':
			flag = 'r';
			break;
		case 'd':
			flag = 'd';
			break;
		default:
			usage(argv[0]);
		}		
	}
	if (optind + 1 != argc)
		usage(argv[0]);
	int id = atol(argv[optind]);
	sysv_msg(flag, id,msgflg);
	return 0;
}
