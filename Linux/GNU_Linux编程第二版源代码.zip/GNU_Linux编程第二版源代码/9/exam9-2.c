// exam9-2.c
#include <stdio.h>
#include <stdlib.h>
char buffer[BUFSIZ];
int main(int argc, char *argv[])
{
	if (argc != 2) {
		fprintf(stderr, "Usage: %s cmdline\n", argv[0]);
		exit(1);
	}
	FILE *fp = popen(argv[1],"r");
	int line = 1;
	while (fgets(buffer, BUFSIZ, fp) != NULL){
		printf("%d: %s", line ++, buffer);
	}
	pclose(fp);
	return 0;
}
