// exam9-12.c
#include	<stdio.h>
#include	<err.h>
#include	<unistd.h>
#include	<stdlib.h>
#include	<fcntl.h>
#include	<sys/types.h>
void usageError(const char *prgname)
{
	fprintf(stderr,"Usage:%s [-r] [-w] [-t time] filename [start] [len] \n",prgname);
	fprintf(stderr, "-r   read lock \n");
	fprintf(stderr, "-w write lock\n");
	fprintf(stderr, "-t  sleep time-seconds\n");
	exit(1);
}
int  main(int argc, char *argv[])
 {
     int type, opt;
     int nsecs = 0;
	int fd;
     type = F_WRLCK;
	while ((opt = getopt(argc, argv, "rwt:")) != -1) {
		switch (opt) {
		case 'r':
			type = F_RDLCK;
			break;
		case 'w':
			type = F_WRLCK;
			break;
		case 't':
			nsecs = atoi(optarg);
			break;
		default: 
			usageError(argv[0]);
			exit(1);
		}
	}
	if ( optind > argc -1)
			usageError(argv[0]);
	if ((fd = open(argv[optind], O_RDWR))==-1)
		err(1,"open file %s failed\n",argv[optind]);
	struct flock lock;
	lock.l_type = type;
	lock.l_whence = SEEK_SET;
	lock.l_start = (optind+1<=argc-1) ? atol(argv[optind+1]): 0;
	lock.l_len =   (optind+2<=argc-1) ? atol(argv[optind+2]): 0;
	if (fcntl (fd, F_SETLK, &lock) == -1)
		err(1,"fcntl failed \n");
	printf("lock sucess\n");
	sleep(nsecs);
	lock.l_type = F_UNLCK;  
	if (fcntl(fd, F_SETLK, &lock)==-1)
		err(1,"unlock failed \n");
	printf("unlock sucess\n");
	close(fd);
	exit(0);
}
