//exam9-3.c
#include <sys/mman.h>
#include <err.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
int main(int argc, char *argv[])
{
	if (argc != 3) {
		fprintf(stderr, "Usage: %s strung1 string2\n", argv[0]);
		exit(1);
	}
	int fd = open("/dev/zero", O_RDWR, 0);
	char *anon, *zero;
    anon = (char*)mmap(NULL, 4096, PROT_READ|PROT_WRITE, MAP_ANON|MAP_SHARED,-1, 0);
    zero = (char*)mmap(NULL, 4096, PROT_READ|PROT_WRITE, MAP_FILE|MAP_SHARED, fd, 0);
	strcpy(anon, argv[1]);
	strcpy(zero, argv[1]);
	printf("anonymous:%s \t zero-backed:%s\n", anon, zero);
	switch ((fork())) {
		case 0:
			strcpy(anon, argv[2]);
			strcpy(zero, argv[2]);
			munmap(anon, 4096);
			munmap(zero, 4096);
			close(fd);
			return 0;
	}
	sleep(3);
	printf("anonymous:%s \t zero-backed:%s\n", anon, zero);
	munmap(anon, 4096);
	munmap(zero, 4096);
	close(fd);
	return 0;
}
