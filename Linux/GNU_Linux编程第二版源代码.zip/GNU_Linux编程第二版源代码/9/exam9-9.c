//exam9-9.c
#include <mqueue.h>
#include <sys/stat.h>
#include <stdio.h>
#include <stdlib.h>
#include <err.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
char *msg = "hello posix message\n";
void usage(const char *prgname)
{
	fprintf(stderr, "Usage: %s -<c|s message|r|d>  [-p priority] /name\n", prgname);
	fprintf(stderr, "-c   Create posix message queue \n");
	fprintf(stderr, "-s send posix message \n");
	fprintf(stderr, "-r receive posix message\n");
	fprintf(stderr, "-d unlink posix message queue\n");
	exit(1);
}
void create_posix_mq(const char *name){
	struct mq_attr attr;
    attr.mq_maxmsg = 5;
    attr.mq_msgsize = 1024;
	mqd_t mqd = mq_open(name, O_RDWR| O_CREAT,(S_IRUSR|S_IWUSR),&attr);
	if (mqd == (mqd_t) -1)
		err(1,"mq_open\n");
	printf("create message queue success\n");
}
void send_posix_mq(const char *name, char *msg, unsigned int prio){
	mqd_t mqd = mq_open(name, O_WRONLY);
	if (mqd == (mqd_t) -1)
		err(1,"mq_open\n");
	mq_send(mqd, msg, strlen(msg), prio);
	printf("send message queue success\n");		
}
void receive_posix_mq(const char *name, unsigned int prio){
	mqd_t mqd = mq_open(name, O_RDONLY);  
	if (mqd == (mqd_t) -1)
		err(1,"mq_open\n");
	struct mq_attr attr;
	mq_getattr(mqd, &attr);
	void *buff;		
	buff = malloc(attr.mq_msgsize); 
	ssize_t nread = mq_receive(mqd, buff, attr.mq_msgsize,&prio);
	write(1, buff, nread);
	printf("\n");
}
void unlink_posix_mq(const char *name){
	mq_unlink(name);
	printf("unlink message queue success\n");		
}
int main(int argc, char *argv[])
{
	int opt;
	int prio = 0;
	char flag;
	while ((opt = getopt(argc, argv, "cs:rdp:")) != -1) {
		switch (opt) {
			case 'c':
				flag = 'c';
				break;
			case 's':
				flag = 's';
				msg = optarg;
				break;
			case 'p':
				prio = atol(optarg);
				break;
			case 'r':
				flag = 'r';
	  			break;
			case 'd':
				flag = 'd';
				break; 
			default:
				usage(argv[0]);
		}
	}
	if (optind +1 != argc)
		usage(argv[0]);
	char *name = argv[optind];
	if(flag == 'c')		create_posix_mq(name);
	if(flag == 's')		send_posix_mq(name, msg, prio);
	if(flag == 'r')		receive_posix_mq(name, prio);
	if(flag == 'd')		unlink_posix_mq(name);
	return 0;
}
