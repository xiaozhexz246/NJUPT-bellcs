//exam9-1.c
#include <sys/wait.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
char buffer[BUFSIZ];
int main(int argc, char *argv[])
{
	if (argc != 2) {
		fprintf(stderr, "Usage: %s <string>\n", argv[0]);
		exit(1);
	}
	int pipefd[2];
	pipe(pipefd);
	pid_t pid = fork();
	if (pid == 0) {
		close(pipefd[1]);   
		while (read(pipefd[0], &buffer, 1) > 0)
			write(1, &buffer, 1);
		write(1, "\n", 1);
		close(pipefd[0]);
		_exit(0);
	} else {
		close(pipefd[0]);   
		write(pipefd[1], argv[1], strlen(argv[1]));
		close(pipefd[1]);   
		wait(NULL);  
		exit(0);
	}
}
