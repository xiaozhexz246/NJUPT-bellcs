// exam9-11.c
#include <sys/file.h>
#include	<stdio.h>
#include	<err.h>
#include	<unistd.h>
#include	<stdlib.h>
void usage(const char *prgname)
{
	fprintf(stderr, "Usage: %s [-s] [-e] [-t time] filename\n", prgname);
	fprintf(stderr, "-s   shared lock \n");
	fprintf(stderr, "-e exclusive lock\n");
	fprintf(stderr, "-t  sleep time-seconds\n");
	exit(1);
}
int  main(int argc, char *argv[])
 {
	int opt;
     int type = LOCK_EX, nsecs = 0;
	while ((opt = getopt(argc, argv, "set:")) != -1) {
		switch (opt) {
			case 's':
				type = LOCK_SH;
				break;
			case 'e':
				type = LOCK_EX;
				break;
			case 't':
				nsecs = atoi(optarg);
				break;
			default: 
				usage(argv[0]);
		}
	}
	if (optind > argc -1)
			usage(argv[0]);
	int fd = open(argv[optind], O_RDWR);
	if (fd == -1)
		err(1, "%s", argv[optind]);
	flock(fd, type);
	printf("lock sucess\n");
	sleep(nsecs);
	flock(fd, LOCK_UN);
	printf("unlock sucess\n");
	close(fd);
	exit(0);
}
