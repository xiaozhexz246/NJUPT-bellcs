//exam9-4.c
#include <stdio.h>
#include <sys/sem.h>
#include <stdlib.h>
#include <unistd.h>
#include <err.h>
void usage(char *prgname)
{
	fprintf(stderr, "Usage:%s   -<c|s|r|l|d> semid index\n", prgname);
	fprintf(stderr, "-c: create semaphore\n");
	fprintf(stderr, "-s: send semaphore\n");
	fprintf(stderr, "-r: receive semaphore\n");
	fprintf(stderr, "-l: list semaphore\n");
	fprintf(stderr, "-d: delete semaphore\n");
	exit(1);
}
void sysv_sem(char cmd, key_t id,int index, int semflg)
{
	int cnt;
	struct sembuf sb;
	int semid = semget(id, index, semflg);
	if (semid == -1)
		err(1,"semget\n");
	switch (cmd) {
		case 'c':
			break;
		case 's':
			sb.sem_num = index;
			sb.sem_flg = 0;
			sb.sem_op = 1;
			semop(semid, &sb, 1);
			break;
		case 'r':
			sb.sem_num = index;
			sb.sem_flg = 0;
			sb.sem_op = -1; 
			semop(semid, &sb, 1);
			break;
		case 'l':
			cnt = semctl(semid, index, GETVAL);
			printf("current semaphore  %d.\n", cnt);
			break;
		case 'd':
			semctl(semid, 0, IPC_RMID);
			break;
	}
}
int main(int argc, char *argv[])
{
	int opt, semflg = 0;
	char flag = 'c';
	while ((opt = getopt(argc, argv,"csrld")) != -1) {
		switch (opt) {
			case 'c':
				flag = 'c';
				semflg = IPC_CREAT | 0666;
				break;
			case 's':
				flag = 's';
				break;
			case 'r':
				flag = 'r';
				break;
			case 'l':
				flag = 'l';
				break;
			case 'd':
				flag = 'd';
				break;
			default:
				usage(argv[0]);
		}
	}
	if (optind + 2 != argc)
		usage(argv[0]);
	key_t id = atol(argv[optind]);
	int index = atol(argv[optind + 1]);
	sysv_sem(flag, id,index, semflg);
	return 0;
}
