//exam9-7.c
#include <fcntl.h>           
#include <sys/stat.h>        
#include <semaphore.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <err.h>
void usage(char *prgname)
{
	fprintf(stderr, "Usage: %s -<c|p|w|q|d> name\n", prgname);
	fprintf(stderr, "-c   Create posix semaphore \n");
	fprintf(stderr, "-p post posix semaphore\n");
	fprintf(stderr, "-w wait posix semaphore\n");
	fprintf(stderr, "-q query posix semaphore\n");
	fprintf(stderr, "-d unlink posix semaphore\n");
	exit(1);
}
void create_posix_sem(const char *name){
	sem_t *psem = sem_open(name, O_CREAT, S_IRUSR|S_IWUSR, 0);
	if (psem == SEM_FAILED)
		err(1,"sem_open\n");
	printf("create posix semaphore success\n");
}
void post_posix_sem(const char *name){
	sem_t *psem = sem_open(name, 0); 
	if (psem == SEM_FAILED)
		err(1,"sem_open\n");
	sem_post(psem);
	printf("%ld post posix semaphore success\n",(long)getpid());
}
void wait_posix_sem(const char *name){
	sem_t *psem = sem_open(name, 0);
	if (psem == SEM_FAILED)
		err(1,"sem_open\n");
	sem_wait(psem);
	printf("%ldwait posix semaphore succeeded\n",(long)getpid());
}
void query_posix_sem(const char *name){
	sem_t *psem = sem_open(name, 0);
	if (psem == SEM_FAILED)
		err(1,"sem_open\n");
	int value;
	sem_getvalue(psem, &value);
	printf("get posix semaphore value %d\n", value);	
}
void unlink_posix_sem(const char *name){
	sem_unlink(name);
	printf("unlink posix semaphore success\n");	
}
int main(int argc, char *argv[]){
	int opt;
	char flag;
	while ((opt = getopt(argc, argv, "cpwld")) != -1) {
		switch (opt) {
			case 'c':
				flag = 'c';
				break;
			case 'p':
				flag = 'p';
				break;
			case 'w':
				flag = 'w';
	  			break;
			case 'l':
				flag = 'l';
				break;
			case 'd':
				flag = 'd';
				break; 
			default:
				usage(argv[0]);
		}
	}
	if (optind+1 !=argc)
		usage(argv[0]);
	char *name = argv[optind];
	if(flag == 'c')		create_posix_sem(name);
	if(flag == 'p')		post_posix_sem(name);		
	if(flag == 'w')		wait_posix_sem(name);
	if(flag == 'l')		query_posix_sem(name);
	if(flag == 'd')		unlink_posix_sem(name);
	return 0;
}
