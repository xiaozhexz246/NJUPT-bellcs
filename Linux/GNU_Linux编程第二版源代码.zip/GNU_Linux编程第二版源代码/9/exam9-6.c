// exam9-6.c
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <err.h>
#include <sys/shm.h>
#define shmsize 4096
char *msg;
void usage(char *prgname)
{
	fprintf(stderr, "Usage:%s   -<c|w|r|d> shmid\n", prgname);
	fprintf(stderr, "-c: create shared memory\n");
	fprintf(stderr, "-w: write shared memory\n");
	fprintf(stderr, "-r: read shared memory\n");
	fprintf(stderr, "-d: delete shared memory\n");
	exit(1);
}
void sysv_shm(char cmd, key_t id,int shmflg)
{
	char *mem;
	int shmid = shmget(id, shmsize, shmflg);
	if (shmid == -1)
		err(1,"shmget \n");
	switch (cmd) {
		case 'c':
			printf( "Created shared memory success %d\n", shmid);
			break;
		case 'w':
			mem = shmat(shmid, NULL, 0);
		    strcpy((char *)mem,msg);
		    shmdt( mem );
			break;
		case 'r':
			mem = shmat(shmid, NULL, 0);
			printf("%s", (char *)mem);
			shmdt( mem );
			break;
		case 'd':
			shmctl(shmid, IPC_RMID, NULL );
			break;
	}
}
int main(int argc, char *argv[])
{
	int opt;
	char flag = 'c';
	int  shmflg = 0;
	while ((opt = getopt(argc, argv,"cw:rd")) != -1){
		switch (opt) {
		case 'c':
			flag = 'c';
			shmflg = IPC_CREAT | 0666;
			break;
		case 'w':
			flag = 'w';
			msg = optarg;
			break;
		case 'r':
			flag = 'r';
			break;
		case 'd':
			flag = 'd';
			break;
		default:
			usage(argv[0]);
		}
	}
	if (optind+1 != argc)
		usage(argv[0]);
	int id = atol(argv[optind]);
	sysv_shm(flag, id, shmflg);
	return 0;
}
