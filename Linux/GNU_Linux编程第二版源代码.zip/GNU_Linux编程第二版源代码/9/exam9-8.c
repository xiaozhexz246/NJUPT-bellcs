//exam9-8.c
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <semaphore.h>
#include <time.h>
#include <errno.h>
#include <signal.h>
sem_t sem;
void sighandler(int sig)
{
	write(1, "sem_post() from sighandler\n", 27);
	if (sem_post(&sem) == -1) {
		write(2, "sem_post() failed\n", 18);
	_exit(1);
    }
}
int main(int argc, char *argv[])
{
	if (argc != 3) {
		fprintf(stderr, "Usage: %s <alarm-secs> <wait-secs>\n", argv[0]);
		exit(1);
	}
	struct sigaction sa;
	sem_init(&sem, 0, 0);
	sa.sa_handler = sighandler;
	sigemptyset(&sa.sa_mask);
	sa.sa_flags = 0;
	sigaction(SIGALRM, &sa, NULL);
	alarm(atoi(argv[1]));
	struct timespec ts;
	clock_gettime(CLOCK_REALTIME, &ts);
	ts.tv_sec += atoi(argv[2]);
	int s;
	while ((s = sem_timedwait(&sem, &ts)) == -1 && errno == EINTR)
		continue;
    if (s == -1) {
		if (errno == ETIMEDOUT)
			printf("sem_timedwait timed out\n");
		else
			perror("sem_timedwait");
	} 
	printf("sem_timedwait succeeded\n");
	exit((s == 0) ? 0 : 1);
}
