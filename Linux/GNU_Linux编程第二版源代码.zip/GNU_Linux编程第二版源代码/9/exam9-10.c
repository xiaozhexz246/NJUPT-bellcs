//exam9-10.c
#include <sys/mman.h>
#include <sys/stat.h>
#include <stdio.h>
#include <err.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
void usage(const char *prgname)
{
	fprintf(stderr, "Usage: %s -<c|w message|r|d>  name\n", prgname);
	fprintf(stderr, "-c   Create posix shared memory \n");
	fprintf(stderr, "-w write posix shared memory\n");
	fprintf(stderr, "-r read posix shared memory\n");
	fprintf(stderr, "-d unlink posix shared memory\n");
	exit(1);
}
void create_posix_shm(const char *name){
	if (shm_open(name, O_RDWR | O_CREAT, S_IRUSR|S_IWUSR) == -1)
		err(1,"shm_open\n");
	printf("create posix shared memory sucess \n");
}
void write_posix_shm(const char *name, char *msg){
	int fd = shm_open(name, O_RDWR, 0);
	if (fd == -1)
		err(1,"shm_open\n");
	size_t len = strlen(msg);
	ftruncate(fd, len);
	char *addr = mmap(NULL, len, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
		if (addr == MAP_FAILED)
		err(1,"mmap\n");
	close(fd);
	memcpy(addr, msg, len);
	printf("write posix shared memory sucess \n");
}
void read_posix_shm(const char *name){
	int fd = shm_open(name, O_RDONLY, 0);
	if (fd == -1)
		err(1,"shm_open\n");
	struct stat stat;	
	fstat(fd, &stat);
	char *addr = mmap(NULL, stat.st_size, PROT_READ, MAP_SHARED, fd, 0);
	close(fd);
	write(1, addr, stat.st_size);
	printf("\n");    
}
void unlink_posix_shm(const char *name){
	shm_unlink(name);
	printf("unlink posix shared memory sucess \n");        
}
int main(int argc, char *argv[])
{
	int opt;
	char flag,* msg;
	while ((opt = getopt(argc, argv, "cw:rd")) != -1) {
		switch (opt) {
			case 'c':
				flag = 'c';
				break;
			case 'w':
				flag = 'w';
				msg = optarg;
				break;
			case 'r':
				flag = 'r';
				break;
			case 'd':
				flag = 'd';
				break;
			default:
				usage(argv[0]);
		}
	}
	if (optind+1 != argc)
		usage(argv[0]);
	char *name = argv[optind];
	if(flag == 'c')		create_posix_shm(name);
	if(flag == 'w')		write_posix_shm(name, msg);
	if(flag == 'r')		read_posix_shm(name);
	if(flag == 'd')		unlink_posix_shm(name);
	return 0;
}
