//exam10-6.c
#include <sys/timerfd.h>
#include <time.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>
int main(int argc, char *argv[])
{
	if (argc  != 3){
		fprintf(stderr, "%s it_interval it_value\n", argv[0]);
		exit(1);
	}
	struct timespec now;
	clock_gettime(CLOCK_REALTIME, &now);
	struct itimerspec new_value;
	new_value.it_interval.tv_sec = atoi(argv[1]);
	new_value.it_interval.tv_nsec = 0;
	new_value.it_value.tv_sec = now.tv_sec + atoi(argv[2]);
	new_value.it_value.tv_nsec = now.tv_nsec;
	int fd = timerfd_create(CLOCK_REALTIME, 0);
	timerfd_settime(fd, TFD_TIMER_ABSTIME, &new_value, NULL);
	uint64_t exp, tot_exp = 0;
	for (int i = 1; i < 5; i++) {
		read(fd, &exp, sizeof(uint64_t));
		tot_exp += exp;
		printf("read: %lld  total = %lld\n",
		(unsigned long long)exp, (unsigned long long)tot_exp);
	}
	exit(0);
}
