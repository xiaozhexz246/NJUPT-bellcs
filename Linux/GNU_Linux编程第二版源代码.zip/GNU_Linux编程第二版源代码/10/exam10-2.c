//exam10-2.c
#include <stdio.h> 
#include <unistd.h> 
#include <stdlib.h> 
#include <sys/times.h> 
int main(int argc, char *argv[])
{ 
	struct tms stime, etime;
	clock_t   ticks_persceond;
	clock_t stime_tick, etime_tick ;
	int opt, numloop, numCalls;
	numloop = 0; numCalls = 0;
	while ((opt = getopt(argc, argv,"u:s:")) != -1) {
		switch (opt) {
			case 'u':
				numloop = atol(optarg);
				break;
			case 's':
				numCalls = atol(optarg);
				break;
			default:
				fprintf(stderr, "Usage:%s [-u loop num] [-s syscall num\n", argv[0]);
				exit(1);
 		}
	}
	ticks_persceond = sysconf(_SC_CLK_TCK);  
	printf("ticks_persceond:%ld\n", ticks_persceond);
	stime_tick = times(&stime);   
	for (int j = 0; j < numCalls; j++)
		getppid();
	for (int i = 0; i < numloop; i++){
		int sum = 0;
		for (int i = 0; i < 10000; i++)
			sum += i;
	}
	etime_tick = times (&etime);   
	printf("times is:%ld \n", etime_tick-stime_tick); 
	printf("user time is : %ld \n", ((etime.tms_utime - stime.tms_utime)));   
	printf ("kernel time is : %ld \n",((etime.tms_stime - stime.tms_stime)));
	return (0);
}
