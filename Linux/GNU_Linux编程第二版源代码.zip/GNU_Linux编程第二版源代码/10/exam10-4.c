// exam10-4.c
#include <errno.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h> 
#include <sys/time.h>
int count = 0;
void usage(char *prgname)
{
	fprintf(stderr, "Usage: %s [-r] [-v] [-p] it_interval it_value\n", prgname);
	fprintf(stderr, "-r: ITIMER_REAL\n");
	fprintf(stderr, "-v: ITIMER_VIRTUAL\n");
	fprintf(stderr, "-p: ITIMER_PROF\n");
	exit(1);
}
void sighandler(int sig){
	int errsave = errno;
	switch (sig){
		case SIGALRM:
			printf("caught signal SIGALRM %d\n", count);
			break;
		case SIGVTALRM:
			printf("caught signal SIGVTALRM %d\n", count);
			break;
		case SIGPROF:
			printf("caught signal SIGPROF %d\n", count);
			break;
		default:
			printf("rest signal\n");
		break;
	}
	errno = errsave;
}
int  main(int argc, char *argv[])
{
	int opt;
	int timertype = ITIMER_REAL;
	int sigtype = SIGALRM;
	while ((opt = getopt(argc, argv, "rvp")) != -1) {
		switch (opt) {
			case 'r':
				timertype = ITIMER_REAL;
				sigtype = SIGALRM;                   
				break;
			case 'v':
				timertype = ITIMER_VIRTUAL;
				sigtype = SIGVTALRM;
				break;
			case 'p':
				timertype = ITIMER_PROF;
				sigtype = SIGPROF;
				break;
			default:
				usage(argv[0]);
		}
	}
	if (optind + 2 > argc)
		usage(argv[0]);
	struct sigaction act;				
	act.sa_handler = sighandler;
	act.sa_flags = 0;
	sigemptyset(&act.sa_mask);
	sigaction(sigtype, &act, NULL);	
	struct itimerval value;
	value.it_interval.tv_sec = atol(argv[optind]);
	value.it_interval.tv_usec = 0;
	value.it_value.tv_sec = atol(argv[optind + 1]);  
	value.it_value.tv_usec = 0;    
	setitimer(timertype, &value, NULL);
	for (count = 1; count<5; count++)
		pause();
	return 0;
}
