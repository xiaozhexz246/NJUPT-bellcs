//exam10-5.c
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <signal.h>
#include <time.h>
int count = 0;
void siginfohandler(int sig, siginfo_t *si, void *ucontext)
{
	timer_t *tidp = si->si_value.sival_ptr;
	printf("*sival_ptr = 0x%lx\n", (long)*tidp);
}
int main(int argc, char *argv[])
{
	if (argc != 3) {
		fprintf(stderr, "Usage: %s it_interval it_value\n", argv[0]);
		exit(1);
	}
	struct sigaction sa;
	sa.sa_flags = SA_SIGINFO;
	sa.sa_sigaction = siginfohandler;
	sigemptyset(&sa.sa_mask);
	sigaction(SIGRTMIN, &sa, NULL);
	struct sigevent sev;
	sev.sigev_notify = SIGEV_SIGNAL;
	sev.sigev_signo = SIGRTMIN;
	sev.sigev_value.sival_ptr = &count;
	timer_t timerid;
	timer_create(CLOCK_REALTIME, &sev, &timerid);
	printf("timer ID is 0x%lx\n", (long) timerid);
	struct itimerspec its;
	its.it_interval.tv_sec = atoll(argv[1]);
	its.it_interval.tv_nsec = 0;
	its.it_value.tv_sec = atoll(argv[2]);
	its.it_value.tv_nsec = 0;
	timer_settime(timerid, 0, &its, NULL);
	for (count = 1; count<5; count++)
		pause();
	timer_delete(timerid);
	return 0;
}
