//exam10-3.c
#include <sys/time.h>
#include <time.h>
#include <signal.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
void sighandler(int sig)
{
    return;                             
}
int main(int argc, char *argv[])
{
	if (argc!=2){
		fprintf(stderr, "Usage:%s  seconds\n", argv[0]);
		exit(1);
	}
	struct sigaction sa;
	sigemptyset(&sa.sa_mask);
	sa.sa_flags = 0;
	sa.sa_handler = sighandler;
	sigaction(SIGINT, &sa, NULL);
	struct timespec request;
	request.tv_sec = atol(argv[1]);
	request.tv_nsec = 0;
	for (;;) {
	struct timespec remain;	
		int s = clock_nanosleep(CLOCK_REALTIME, 0, &request, &remain);
		if (s != 0 && s != EINTR)
			break;
		if (s == 0)
			break;  
		printf("Remaining: %ld.%09ld\n",
		(long) remain.tv_sec, remain.tv_nsec);                    
		request = remain;
    }
	return(0);
}
