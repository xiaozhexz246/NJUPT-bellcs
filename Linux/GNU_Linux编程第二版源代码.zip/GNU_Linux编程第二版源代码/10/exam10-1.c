//exam10-1.c
#include<stdio.h>
#include<sys/time.h>
#include<time.h> 
#include<unistd.h>
#define TS_BUF_SIZE sizeof("YYYY-MM-DD HH:MM:SS")       
int  main(int  argc, char *argv[])
{
	struct tm *loc;
	struct  timeval tv;
	struct  timezone  tz;
	gettimeofday(&tv,&tz);
	printf("gettimeofday tv_sec:%ld\n",(long) tv.tv_sec);
	printf("gettimeofday tv_usec:%ld\n", tv.tv_usec);
	printf("gettimeofday tz_minuteswest:%d\n", tz.tz_minuteswest);
	printf("gettimeofday tz_dsttime:%d\n", tz.tz_dsttime);
	struct timespec ts;
	clock_getres(CLOCK_REALTIME, &ts);
	printf("clock_getres tv_sec:%ld\n",(long)ts. tv_sec);
	printf("clock_getres tv_nsec:%ld\n", ts.tv_nsec);
	clock_gettime(CLOCK_REALTIME, &ts);
	printf("clock_gettime tv_sec:%ld\n",(long) ts.tv_sec);
	printf("clock_gettime tv_nsec:%ld\n", ts.tv_nsec);
	time_t t = time(NULL);
	printf("time:%ld\n",(long) t);
	loc = localtime(&t);
	char timestamp[80];
	strftime(timestamp, TS_BUF_SIZE, "%F %X", loc);
	printf("%s\n", timestamp); 
}
