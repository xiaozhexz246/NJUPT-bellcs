//script5-1.sh
#!/bin/bash
gcc  -c  app.c  
gcc -c  main.c  
gcc -c  frame.c  
gcc  -c component.c  
gcc  -c lib.c  
gcc   add.o main.o frame.o component.o lib.o  -o app
