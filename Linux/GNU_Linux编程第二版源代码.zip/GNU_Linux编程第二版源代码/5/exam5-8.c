// exam5-8.c
#include<stdio.h>
#include<stdlib.h>
#include<errno.h> 
#include<string.h> 
int main()
{
	for (int i = 0; i <= 256;i++)  {
		printf("errno:%2d\t%s\n", i, strerror(i));
	}
	return 0;
}

