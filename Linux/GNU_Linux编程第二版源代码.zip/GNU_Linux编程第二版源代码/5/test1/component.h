// app.h
#ifndef COMPONENT_API_H
#define COMPONENT_API_H
	void mycmpt_do_work();
	extern void init_mycomponent();
#endif
