// main.c
#include "frame.h"
int main(int argc, char *argv[])
{
	init_framework();
	do_framework();
}


