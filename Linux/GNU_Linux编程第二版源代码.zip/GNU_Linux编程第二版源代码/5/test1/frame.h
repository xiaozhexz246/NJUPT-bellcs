// frame.h
#ifndef FRAME_API_H
#define FRAME_API_H
	struct component_operations 
	{
		void (*do_work) ();
	};
	extern void init_framework();
	extern void do_framework();
	extern void register_component(struct component_operations *p );
#endif
