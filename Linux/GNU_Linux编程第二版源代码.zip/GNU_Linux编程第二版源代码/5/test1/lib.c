// lib.c
int add(int x, int y){ 
  return x + y; 
}
int mod(int x, int y)
{
   return x%y;
}
 int func(int count)
{
  int sum = 0;
	for ( int i = 0;i <= count; i++)
		sum += i;
	return sum;
}
