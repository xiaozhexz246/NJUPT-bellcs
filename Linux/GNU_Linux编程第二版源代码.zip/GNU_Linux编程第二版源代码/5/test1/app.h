// app.h
#ifndef APP_API_H
#define APP_API_H
#include "frame.h"
extern void connect_component();
extern void mywork();
#endif
