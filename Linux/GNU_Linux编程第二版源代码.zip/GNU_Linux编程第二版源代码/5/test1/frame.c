// fram.c
#include <stdio.h>
#include "frame.h"
#include "app.h"
struct component_operations  *pcompt=NULL;

void register_component(struct component_operations *p )
{
	pcompt = p;
}
void init_framework()
{
	connect_component();
}
void do_framework()
{
	if(pcompt)
		pcompt->do_work();
	mywork();
}
