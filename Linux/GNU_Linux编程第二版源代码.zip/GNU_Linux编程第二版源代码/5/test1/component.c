// component.c
#include<stdio.h>
#include "component.h"
#include "frame.h"
#include "lib.h"
struct component_operations mycmpy ={
	.do_work = mycmpt_do_work
};
void mycmpt_do_work()
{
	printf("do my component\n");
}
void init_mycomponent()
{
	register_component(&mycmpy);

}

