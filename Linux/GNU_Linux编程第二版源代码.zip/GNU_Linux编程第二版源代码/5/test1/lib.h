// add.h
#ifndef LIB_API_H
#define LIB_API_H
	extern int add(int x, int y);
	extern int mod(int x, int y);
	extern  int func(int count);
	#endif
