//app.c
#include <stdio.h>
#include "lib.h"

#include "component.h"
void connect_component()
{
	init_mycomponent();
}
void mywork()
{
  int val;
   int x, y;
   x = 121;
   y = 9;
   val = add(x, y);
   printf("the mult of x and y is %d\n", val);
   val = func(100);
   printf("the sum is%d \n", val);
   printf("the mod is %d\n", mod(x, y));

}


