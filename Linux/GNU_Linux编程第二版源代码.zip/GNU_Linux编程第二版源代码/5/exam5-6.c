// exam5-6.c
char * pstr = "Welcome to build your program\n";
char **envp;
static int write(int fd, const void * buffer, int size)
{
	int ret;
	asm (
		"int  $0x80    "
		: "=a" (ret)  
		: "a" (4),"b" (fd),"c" (buffer),"d" (size)  
	);
	return ret;
}
static void exit(int status)
{
	asm (
		"int  $0x80    "
		:: "a" (1),"b" (status)
	);
}
int stringlen(char *p)
{
	int i =0;
	while (*p++ != '\0')
		i++;
	return i;
}
int main(int argc,char *argv[])
{
	int len = stringlen(pstr);
	write(1,pstr,len);
	return 0;
}
char *bp = 0;
void init(void)
{
	int argc,sz = sizeof(long);
	char ** argv;
#ifdef __x86_64__
	asm ("mov %rbp,bp");
#elif  __i386__
		asm ("mov %ebp,bp");
#endif
	argc = (int)*(bp + sz);
	argv = (char **) (bp + 2*sz);
	envp = (char **) (bp +(argc+3)*sz);
	int ret = main(argc,argv);
	exit(ret);
}
