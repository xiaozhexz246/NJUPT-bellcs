// exam5-1.c
#include<stdio.h>
int count =20;
int main(void)
{
	 int sum = 0;
#ifdef DEBUG
	printf("runing in debug mode\n");
#else
	printf(" runing in no debug mode\n");
#endif
	 for (int i = 0; i < count; i++)
		sum += i;
	printf("the sum is:\t%d\n", sum);
}
