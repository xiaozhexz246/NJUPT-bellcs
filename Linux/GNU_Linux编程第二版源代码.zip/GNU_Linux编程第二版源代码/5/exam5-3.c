// exam5-3.c
int func(int count)
{
  int sum = 0;
	for ( int i = 0;i <= count; i++)
		sum += i;
	return sum;
}
