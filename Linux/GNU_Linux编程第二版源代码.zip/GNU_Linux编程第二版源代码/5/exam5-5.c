// exam5-5.c
#include<stdio.h>
#include "exam5-4.h"
int main(void)
{
	int val;
	int x, y;
	x = 12;
	y = 18;
	val = add(x, y);
	printf("the mult of x and y is %d\n", val);
	val = func(100);
	printf("the sum is:\t%d \n", val);
	return 0;
}
