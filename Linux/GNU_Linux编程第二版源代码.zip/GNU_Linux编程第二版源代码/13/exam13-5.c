//exam13-5.c
#include  <unistd.h>
#include  <sys/socket.h>      
#include  <arpa/inet.h>       
#include <stdlib.h>
#include <fcntl.h>
#include <stdio.h>
#include <poll.h> 
#define OPEN_MAX          40960
struct pollfd clientfd[OPEN_MAX];
int numfd = 1;
void clientfd_init()
{
	for (int i = 1; i < OPEN_MAX; i++) 
		clientfd[i].fd = -1; 
}
void clientfd_add(int fd)
{
	if (numfd < OPEN_MAX) {
		clientfd[numfd].fd = fd;
		clientfd[numfd].events = POLLIN;
		clientfd[numfd].revents = 0;
		numfd++;
	}else
		close(clientfd[fd].fd);
}
int clientfd_del(int index)
{
	if (index < (numfd-1)) {
		close(clientfd[index].fd);
		clientfd[index].fd = clientfd[numfd-1].fd;
		clientfd[index].events = clientfd[numfd-1].events;
		clientfd[index].revents = clientfd[numfd-1].revents;
		numfd--;
		return 1;
	}
	return 0;
}
int process_client(int index) 
{
	char buffer[BUFSIZ]; 
	ssize_t len = read(clientfd[index].fd, buffer, BUFSIZ);
	if ((len <= 0))
		return clientfd_del(index);
	else
		write(clientfd[index].fd, buffer, len);
	return 0;
}
int  main(int argc, char **argv)
{
	if (argc!=2){
		fprintf(stderr, "Usage : %s <port>\n", argv[0]);
		exit(1);
	}
	socklen_t socklen = sizeof(struct sockaddr_in);
	struct sockaddr_in	serv_addr;
	serv_addr.sin_family = AF_INET;
	serv_addr.sin_addr.s_addr = htonl(INADDR_ANY);
	serv_addr.sin_port = htons(atoi(argv[1]));
	int serv_sock = socket(AF_INET, SOCK_STREAM, 0);
	int opt = 1;
	setsockopt(serv_sock, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));
	bind(serv_sock, (struct sockaddr *) &serv_addr, socklen);
	listen(serv_sock, 5);
	fcntl(serv_sock, F_SETFL, fcntl(STDIN_FILENO, F_GETFL)|O_NONBLOCK);
	clientfd[0].fd = serv_sock;
	clientfd[0].events = POLLIN;
	clientfd_init();
	for ( ; ; )  {
		poll(clientfd, numfd, -1);
		if  (clientfd[0].revents & POLLIN) {
			struct sockaddr_in cli_addr;
			int fd_sock = accept(serv_sock, (struct sockaddr *) &cli_addr, &socklen);
			fcntl(fd_sock, F_SETFL, fcntl(STDIN_FILENO, F_GETFL)|O_ASYNC|O_NONBLOCK);
			clientfd_add(fd_sock);
		}	
		for (int i = 1; i < numfd; i++) {
			if (clientfd[i].revents & POLLHUP)
				i = i- clientfd_del(i);
			else {
				if (clientfd[i].revents & POLLIN)
					i = i -process_client(i);
			}
		}
	}	
	return 0;
}
