//exam13-6.c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <sys/epoll.h>
#define EPOLL_SIZE 50
#define MAX_EVENTS 100
struct client {
	int fd;
	ssize_t len;
	unsigned char buffer[BUFSIZ];
};
int epfd;
void setnonblockingmode(int fd)
{
	int flag = fcntl(fd, F_GETFL, 0);
	fcntl(fd, F_SETFL, flag|O_NONBLOCK);
}
void io_error(struct client *p)
{
	close(p->fd);
	epoll_ctl(epfd, EPOLL_CTL_DEL, p->fd, NULL);	
	free(p);
	printf("error or closed \n");
}
void io_read(struct client *p)
{
	struct epoll_event ev;
	ev.data.ptr = p;
	p->len = read(p->fd, p->buffer, BUFSIZ);
	if (p->len  > 0){
		ev.events = EPOLLOUT | EPOLLET;  
		epoll_ctl(epfd, EPOLL_CTL_MOD, p->fd, &ev);
	}
	if (p->len == 0)
		io_error(p);
	if ((p->len ==-1) && (errno == EINTR)){
		ev.events = EPOLLIN | EPOLLET;  
		epoll_ctl(epfd, EPOLL_CTL_MOD, p->fd, &ev);
	}	
	if ((p->len == -1) && (errno != EAGAIN) && (errno != EINTR)) 
		io_error(p);
}
void io_write(struct client *p)
{
	struct epoll_event ev;
	ev.data.ptr = p;
	int ret = write(p->fd, p->buffer, p->len);
	if (ret >0){
		ev.events = EPOLLIN | EPOLLET;  
		epoll_ctl(epfd, EPOLL_CTL_MOD, p->fd, &ev);
	}
	if ((ret ==-1) && (errno == EINTR)){
		ev.events = EPOLLOUT | EPOLLET;  
		epoll_ctl(epfd, EPOLL_CTL_MOD, p->fd, &ev);
	}
	if ((ret == -1) && (errno != EAGAIN) && (errno != EINTR)) 
		io_error(p);
}
int main(int argc, char *argv[])
{
	if (argc!=2) {
		fprintf(stderr, "Usage : %s <port>\n", argv[0]);
		exit(1);
	}
	int serv_sock = socket(PF_INET, SOCK_STREAM, 0);
	struct sockaddr_in serv_adr;
	serv_adr.sin_family = AF_INET;
	serv_adr.sin_addr.s_addr = htonl(INADDR_ANY);
	serv_adr.sin_port = htons(atoi(argv[1]));
	bind(serv_sock, (struct sockaddr*) &serv_adr, sizeof(serv_adr));
	listen(serv_sock, 5);
	epfd = epoll_create(EPOLL_SIZE);
	setnonblockingmode(serv_sock);
	struct epoll_event ev;
	ev.events = EPOLLIN;
	ev.data.fd = serv_sock;	
	epoll_ctl(epfd, EPOLL_CTL_ADD, serv_sock, &ev);
	struct epoll_event  events[MAX_EVENTS];
	for ( ; ; ) {
		int event_cnt = epoll_wait(epfd, events, MAX_EVENTS, -1);
		for (int i = 0; i < event_cnt; i++){
			struct client *clt;
			if (events[i].data.fd == serv_sock) {
				struct sockaddr_in  clnt_adr;
				socklen_t adr_sz = sizeof(clnt_adr);
				int fd_sock = accept(serv_sock,(struct sockaddr *) &clnt_adr, &adr_sz);
				setnonblockingmode(fd_sock);
				clt = (void *) malloc(sizeof(struct client));			
				ev.events = EPOLLIN | EPOLLET ; 
				ev.data.ptr = clt;
				epoll_ctl(epfd, EPOLL_CTL_ADD, fd_sock, &ev);
				memset(clt, 0, sizeof(struct client));
				clt->fd = fd_sock;
			}else{
				clt = events[i].data.ptr;
				if (events[i].events & EPOLLIN) 
					io_read(clt);
				if (events[i].events & EPOLLOUT) 
					io_write(clt);
				if (events[i].events & (EPOLLHUP|EPOLLERR)) 
					io_error(clt);
			}
		}
	}
	close(serv_sock);
	close(epfd);
	return 0;
}
