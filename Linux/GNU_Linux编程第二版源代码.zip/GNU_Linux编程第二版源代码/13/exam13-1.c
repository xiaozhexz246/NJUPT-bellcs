//exam13-1.c
#include <fcntl.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <errno.h>
#include <aio.h>
#include <signal.h>
#include <err.h>
int openReqs;
struct iorequest {      
	int	reqNum;
	struct aiocb *aiocbp;
};
void siginfohandler(int sig, siginfo_t *si, void *ucontext)
{
	int savedErrno = errno;
	if (si->si_code == SI_ASYNCIO){
		write(1, "I/O completion signal received\n", 31);
		struct iorequest *p;
		p =(struct iorequest *)si->si_value.sival_ptr;
		int len = aio_return(p->aiocbp);
		printf("read bytes %d:\n", len);
		close(p->aiocbp->aio_fildes);
		free((void *)p->aiocbp->aio_buf);
	}
	openReqs --;		
	errno = savedErrno;
}
int main(int argc, char *argv[])
{
	if (argc < 2) {
		fprintf(stderr, "Usage:%s pathname ...\n", argv[0]);
		exit(1);
	}
	int num = argc - 1;
	struct iorequest *iolist = calloc(num, sizeof(struct iorequest));
	struct aiocb *aiocbList = calloc(num, sizeof(struct aiocb));
	struct sigaction sa;
	sa.sa_flags = SA_RESTART|SA_SIGINFO;
	sa.sa_sigaction = siginfohandler;
	sigaction(SIGRTMIN, &sa, NULL);
	openReqs = num;
	for (int j = 0; j < num; j++) {
		iolist[j].reqNum = j;
		iolist[j].aiocbp = &aiocbList[j];
		iolist[j].aiocbp->aio_fildes = open(argv[j + 1], O_RDONLY);
		if (iolist[j].aiocbp->aio_fildes == -1)
		err(1, "%s", argv[j + 1]);
		printf("opened %s on descriptor %d\n", argv[j + 1], iolist[j].aiocbp->aio_fildes);
		iolist[j].aiocbp->aio_buf = malloc(BUFSIZ);
		iolist[j].aiocbp->aio_nbytes = BUFSIZ;
		iolist[j].aiocbp->aio_reqprio = 0;
		iolist[j].aiocbp->aio_offset = 0;
		iolist[j].aiocbp->aio_sigevent.sigev_notify = SIGEV_SIGNAL;
		iolist[j].aiocbp->aio_sigevent.sigev_signo = SIGRTMIN;
		iolist[j].aiocbp->aio_sigevent.sigev_value.sival_ptr =&iolist[j];
		aio_read(iolist[j].aiocbp);
	}  
	while (openReqs > 0) {
		sleep(10);
	} 
	free(iolist);
	free(aiocbList);
    exit(0);
}
