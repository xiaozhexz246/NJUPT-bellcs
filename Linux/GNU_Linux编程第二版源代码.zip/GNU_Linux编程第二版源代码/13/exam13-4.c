//exam13-4.c
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <string.h>
#include <unistd.h>
#include <sys/time.h>
#include <sys/socket.h>
#include <netinet/in.h>
char buffer[BUFSIZ];
int main(int argc, char **argv)
{
	if (argc!=2){
		fprintf(stderr, "Usage : %s <port>\n", argv[0]);
		exit(1);
	}
	int serv_sock = socket(PF_INET, SOCK_STREAM, 0);
	struct sockaddr_in serv_addr;
	serv_addr.sin_family = AF_INET;
	serv_addr.sin_addr.s_addr = htonl(INADDR_ANY);
	serv_addr.sin_port = htons(atoi(argv[1]));
	bind(serv_sock, (struct sockaddr *) &serv_addr, sizeof(serv_addr));
	listen(serv_sock, 5);
	fcntl(serv_sock, F_SETFL, fcntl(STDIN_FILENO, F_GETFL)|O_ASYNC|O_NONBLOCK);		
	fd_set reads;
	FD_ZERO(&reads);
	FD_SET(serv_sock, &reads);
	int fd_max = serv_sock;
	while (1) {
		fd_set temps = reads;
		select(fd_max+1, &temps, 0, 0, NULL);
		for (int fd = 0; fd < fd_max+1; fd++) {
			if (FD_ISSET(fd, &temps)) {
				if (fd == serv_sock) {
					int fd_sock = accept(serv_sock, (struct sockaddr *)NULL, NULL);
					fcntl(fd_sock, F_SETFL, fcntl(STDIN_FILENO, F_GETFL)|O_ASYNC|O_NONBLOCK);		
					FD_SET(fd_sock, &reads);
					if (fd_max < fd_sock)
					fd_max = fd_sock;
				}
				else {
					ssize_t len = read(fd, buffer, BUFSIZ);
					if (len == 0){
					    FD_CLR(fd, &reads);
					    close(fd);
					}
					else{
					write(fd, buffer, len); 
					}	
				}
			} 
    	} 
	} 
	return 0;
}
