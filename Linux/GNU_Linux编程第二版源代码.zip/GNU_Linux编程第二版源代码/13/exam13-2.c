//exam13-2.c
//#define _GNU_SOURCE
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <err.h>
#include <fcntl.h>
#include <sys/syscall.h>
#include <linux/aio_abi.h>
aio_context_t ctx;
struct ioRequest {
	void (*operate)(struct ioRequest *, long);
	struct iocb *aiocbp;
};
void read_done(struct ioRequest *ioreqp, long nbytes)
{
	printf("read bytes %ld \n", nbytes);
	close(ioreqp->aiocbp->aio_fildes);	
	free((void*)(unsigned long)ioreqp->aiocbp->aio_buf);
	free(ioreqp->aiocbp);
}
int main(int argc, char *argv[])
{
	if (argc < 2) {
		fprintf(stderr, "Usage: %s <pathname> <pathname>...\n", argv[0]);
		exit(1);
	}
	syscall(__NR_io_setup, 128, &ctx);
	int openReqs, numReqs;
	openReqs = numReqs = argc - 1;
	struct ioRequest *ioList;
	ioList = calloc(numReqs, sizeof(struct ioRequest));
	struct iocb *iocbList[128];
	for (int i = 0; i < numReqs; i++) {
		iocbList[i] = calloc(1, sizeof(struct iocb));
	}
	for (int i = 0; i < numReqs; i++) {
		ioList[i].aiocbp = iocbList[i];
		ioList[i].operate = read_done;
		memset(iocbList[i], 0, sizeof(struct iocb));
		iocbList[i]->aio_fildes = open(argv[i + 1], O_RDONLY);
		if (iocbList[i]->aio_fildes == -1)
		err(1, "%s", argv[i + 1]);
		printf("opened %s on descriptor %d\n", argv[i + 1], iocbList[i]->aio_fildes);
		iocbList[i]->aio_buf = (unsigned long) malloc(BUFSIZ);
		iocbList[i]->aio_nbytes = BUFSIZ;
		iocbList[i]->aio_lio_opcode = IOCB_CMD_PREAD;
		iocbList[i]->aio_offset = 0;
		iocbList[i]->aio_data = (unsigned long) & ioList[i];
	}  
	syscall(__NR_io_submit, ctx, numReqs, iocbList);	
	while (openReqs > 0) {
		struct io_event events;
		syscall(__NR_io_getevents, ctx, 1, 1, &events, NULL);
		struct ioRequest *p = (struct ioRequest *)(unsigned long) events.data;
		 p->operate(p, events.res);
		openReqs --;				
	} 
	free(ioList);
	syscall(__NR_io_destroy, ctx);
    exit(0);
}
