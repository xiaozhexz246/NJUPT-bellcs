//exam13-3.c
#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <fcntl.h>
#include <errno.h>
#include <poll.h>
#include <sys/socket.h>
#include <netinet/in.h>
int serv_sock;
char buffer[BUFSIZ]; 
void setsockasync(int sock){
	fcntl(sock, F_SETSIG, SIGIO);
	fcntl(sock, F_SETFL, fcntl(STDIN_FILENO, F_GETFL) | O_ASYNC | O_NONBLOCK);
	fcntl(sock, F_SETOWN, getpid());
}
void sighandler(siginfo_t *si)
{
	switch (si->si_code){
		case POLL_IN:
			if (si->si_fd == serv_sock){
				int fd_sock = accept(serv_sock, (struct sockaddr *)NULL, NULL);	   
				setsockasync(fd_sock);
		   }
		   else{
				ssize_t count = read(si->si_fd, buffer, BUFSIZ);
		   		if (count ==-1)
					close(si->si_fd);
				write(si->si_fd, buffer, count);
				}	   		   			
			break;
		case POLL_OUT:
			break;
		case POLL_ERR:
			close(si->si_fd);
			break;
		case POLL_HUP:
			close(si->si_fd);
			break;
	}
}
int main(int argc, char **argv)
{
	if (argc !=2){
		fprintf(stderr, "Usage : %s <port>\n", argv[0]);
		exit(1);
	}
	sigset_t blockMask;
	sigfillset(&blockMask);
	sigprocmask(SIG_BLOCK, &blockMask, NULL);
	serv_sock = socket(PF_INET, SOCK_STREAM, 0);
	struct sockaddr_in serv_addr;
	serv_addr.sin_family = AF_INET;
	serv_addr.sin_addr.s_addr = htonl(INADDR_ANY);
	serv_addr.sin_port = htons(atoi(argv[1]));
	bind(serv_sock, (struct sockaddr *) &serv_addr, sizeof(serv_addr));
	listen(serv_sock, 5);
	setsockasync(serv_sock);
	for ( ; ; ) {
		siginfo_t si;
		sigwaitinfo(&blockMask, &si);
		switch (si.si_signo){
		case SIGIO:
			sighandler(&si);
			break;
		case SIGINT:
		printf("sigint\n");
		break;
		}
	}
   	exit(0);    
}
